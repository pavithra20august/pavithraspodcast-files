import React, { useState, useEffect } from 'react';
import { Play, Info, ChevronLeft, ChevronRight, Search, Bell, User } from 'lucide-react';

const NetflixApp = () => {
  const [currentHero, setCurrentHero] = useState(0);
  const [movies, setMovies] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Sample fallback movies matching your actual movie posters
  const fallbackMovies = [
    {
      id: 1,
      title: "Avengers: Endgame",
      genre: ["Action", "Adventure"],
      year: 2019,
      rating: "PG-13",
      description: "After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more.",
      backdrop_gradient: "linear-gradient(135deg, #1a3c5c 0%, #2d5a8a 100%)",
      duration: 181,
      imdb_score: 8.4,
      cast: ["Robert Downey Jr.", "Chris Evans", "Scarlett Johansson"],
      director: "Russo Brothers",
      featured: true
    },
    {
      id: 2,
      title: "Black Panther",
      genre: ["Action", "Adventure"],
      year: 2018,
      rating: "PG-13",
      description: "T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future.",
      backdrop_gradient: "linear-gradient(135deg, #2a1a3d 0%, #4a2d6b 100%)",
      duration: 134,
      imdb_score: 7.3,
      cast: ["Chadwick Boseman", "Michael B. Jordan", "Lupita Nyong'o"],
      director: "Ryan Coogler"
    },
    {
      id: 3,
      title: "The Dark Knight",
      genre: ["Action", "Crime", "Drama"],
      year: 2008,
      rating: "PG-13",
      description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
      backdrop_gradient: "linear-gradient(135deg, #1a1a1a 0%, #3d3d3d 100%)",
      duration: 152,
      imdb_score: 9.0,
      cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
      director: "Christopher Nolan"
    },
    {
      id: 4,
      title: "Fast & Furious",
      genre: ["Action", "Crime", "Thriller"],
      year: 2009,
      rating: "PG-13",
      description: "Brian O'Conner, now working for the FBI in LA, teams up with Dominic Toretto to bring down a heroin importer by infiltrating his operation.",
      backdrop_gradient: "linear-gradient(135deg, #3d2a1a 0%, #6b4423 100%)",
      duration: 107,
      imdb_score: 6.5,
      cast: ["Vin Diesel", "Paul Walker", "Michelle Rodriguez"],
      director: "Justin Lin"
    },
    {
      id: 5,
      title: "Black Adam",
      genre: ["Action", "Fantasy"],
      year: 2022,
      rating: "PG-13",
      description: "Nearly 5,000 years after he was bestowed with the almighty powers of the Egyptian gods, Black Adam is freed from his earthly tomb.",
      backdrop_gradient: "linear-gradient(135deg, #2d1b1b 0%, #5c1a1a 100%)",
      duration: 125,
      imdb_score: 6.3,
      cast: ["Dwayne Johnson", "Aldis Hodge", "Pierce Brosnan"],
      director: "Jaume Collet-Serra"
    },
    {
      id: 6,
      title: "Hidden Strike",
      genre: ["Action", "Adventure"],
      year: 2023,
      rating: "PG-13",
      description: "Two elite soldiers must escort civilians through a gauntlet of gunfire and explosions in this action-packed thriller.",
      backdrop_gradient: "linear-gradient(135deg, #3d1a5c 0%, #6b2d8a 100%)",
      duration: 102,
      imdb_score: 5.4,
      cast: ["Jackie Chan", "John Cena", "Pilou Asbæk"],
      director: "Scott Waugh"
    },
    {
      id: 7,
      title: "Oppenheimer",
      genre: ["Biography", "Drama"],
      year: 2023,
      rating: "R",
      description: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.",
      backdrop_gradient: "linear-gradient(135deg, #5c3d1a 0%, #8a6b2d 100%)",
      duration: 180,
      imdb_score: 8.4,
      cast: ["Cillian Murphy", "Emily Blunt", "Robert Downey Jr."],
      director: "Christopher Nolan",
      featured: true
    },
    {
      id: 8,
      title: "Interstellar",
      genre: ["Adventure", "Drama", "Sci-Fi"],
      year: 2014,
      rating: "PG-13",
      description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
      backdrop_gradient: "linear-gradient(135deg, #1a2f4a 0%, #3d5a7a 100%)",
      duration: 169,
      imdb_score: 8.6,
      cast: ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
      director: "Christopher Nolan"
    },
    {
      id: 9,
      title: "Dune",
      genre: ["Adventure", "Drama", "Sci-Fi"],
      year: 2021,
      rating: "PG-13",
      description: "Feature adaptation of Frank Herbert's science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset.",
      backdrop_gradient: "linear-gradient(135deg, #3d2a1a 0%, #8a6b2d 100%)",
      duration: 155,
      imdb_score: 8.0,
      cast: ["Timothée Chalamet", "Rebecca Ferguson", "Zendaya"],
      director: "Denis Villeneuve"
    },
    {
      id: 10,
      title: "John Wick: Chapter 2",
      genre: ["Action", "Crime", "Thriller"],
      year: 2017,
      rating: "R",
      description: "After returning to the criminal underworld to repay a debt, John Wick discovers that a large bounty has been put on his life.",
      backdrop_gradient: "linear-gradient(135deg, #1a1a1a 0%, #3d3d3d 100%)",
      duration: 122,
      imdb_score: 7.4,
      cast: ["Keanu Reeves", "Riccardo Scamarcio", "Ian McShane"],
      director: "Chad Stahelski"
    },
    {
      id: 11,
      title: "Star Wars: The Rise of Skywalker",
      genre: ["Action", "Adventure", "Fantasy"],
      year: 2019,
      rating: "PG-13",
      description: "The surviving members of the resistance face the First Order once again, and the legendary conflict between the Jedi and the Sith reaches its peak.",
      backdrop_gradient: "linear-gradient(135deg, #1a1a3d 0%, #3d3d6b 100%)",
      duration: 141,
      imdb_score: 6.4,
      cast: ["Daisy Ridley", "Adam Driver", "John Boyega"],
      director: "J.J. Abrams"
    },
    {
      id: 12,
      title: "Harry Potter and the Order of the Phoenix",
      genre: ["Adventure", "Family", "Fantasy"],
      year: 2007,
      rating: "PG-13",
      description: "With their warning about Lord Voldemort's return scoffed at, Harry and Dumbledore are targeted by the Wizard authorities.",
      backdrop_gradient: "linear-gradient(135deg, #2d1a3d 0%, #5c2d6b 100%)",
      duration: 138,
      imdb_score: 7.5,
      cast: ["Daniel Radcliffe", "Emma Watson", "Rupert Grint"],
      director: "David Yates"
    },
    {
      id: 13,
      title: "Skyfall",
      genre: ["Action", "Adventure", "Thriller"],
      year: 2012,
      rating: "PG-13",
      description: "James Bond's loyalty to M is tested when her past comes back to haunt her. When MI6 comes under attack, 007 must track down and destroy the threat.",
      backdrop_gradient: "linear-gradient(135deg, #1a3d5c 0%, #2d6b8a 100%)",
      duration: 143,
      imdb_score: 7.8,
      cast: ["Daniel Craig", "Javier Bardem", "Naomie Harris"],
      director: "Sam Mendes"
    },
    {
      id: 14,
      title: "World War Z",
      genre: ["Action", "Drama", "Horror"],
      year: 2013,
      rating: "PG-13",
      description: "Former United Nations employee Gerry Lane traverses the world in a race against time to stop a zombie pandemic.",
      backdrop_gradient: "linear-gradient(135deg, #2d1b1b 0%, #5c1a1a 100%)",
      duration: 116,
      imdb_score: 7.0,
      cast: ["Brad Pitt", "Mireille Enos", "Daniella Kertesz"],
      director: "Marc Forster"
    },
    {
      id: 15,
      title: "Mission: Impossible",
      genre: ["Action", "Adventure", "Thriller"],
      year: 1996,
      rating: "PG-13",
      description: "An American agent, under false suspicion of disloyalty, must discover and expose the real spy without the help of his organization.",
      backdrop_gradient: "linear-gradient(135deg, #3d2a1a 0%, #6b4423 100%)",
      duration: 110,
      imdb_score: 7.2,
      cast: ["Tom Cruise", "Jon Voight", "Emmanuelle Béart"],
      director: "Brian De Palma"
    },
    {
      id: 16,
      title: "Rampage",
      genre: ["Action", "Adventure", "Sci-Fi"],
      year: 2018,
      rating: "PG-13",
      description: "When three different animals become infected with a dangerous pathogen, a primatologist and a geneticist team up to stop them.",
      backdrop_gradient: "linear-gradient(135deg, #2d1b1b 0%, #5c1a1a 100%)",
      duration: 107,
      imdb_score: 6.1,
      cast: ["Dwayne Johnson", "Naomie Harris", "Malin Akerman"],
      director: "Brad Peyton"
    },
    {
      id: 17,
      title: "Looper",
      genre: ["Action", "Drama", "Sci-Fi"],
      year: 2012,
      rating: "R",
      description: "In 2074, when the mob wants to get rid of someone, the target is sent into the past, where a hired gun awaits - someone like Joe.",
      backdrop_gradient: "linear-gradient(135deg, #1a3c5c 0%, #2d5a8a 100%)",
      duration: 119,
      imdb_score: 7.4,
      cast: ["Joseph Gordon-Levitt", "Bruce Willis", "Emily Blunt"],
      director: "Rian Johnson"
    },
    {
      id: 18,
      title: "Terminator: Dark Fate",
      genre: ["Action", "Adventure", "Sci-Fi"],
      year: 2019,
      rating: "R",
      description: "An augmented human and Sarah Connor must stop an advanced liquid Terminator from hunting down a young girl.",
      backdrop_gradient: "linear-gradient(135deg, #1a1a3d 0%, #3d3d6b 100%)",
      duration: 128,
      imdb_score: 6.2,
      cast: ["Linda Hamilton", "Arnold Schwarzenegger", "Mackenzie Davis"],
      director: "Tim Miller",
      featured: true
    }
  ];

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8000/movies', {
          timeout: 5000 // 5 second timeout
        });
        if (!response.ok) throw new Error('API failed');
        const data = await response.json();
        setMovies(data);
      } catch (error) {
        console.error('Error fetching movies, using fallback data:', error);
        setMovies(fallbackMovies);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  useEffect(() => {
    if (movies.length > 0) {
      // Create categories with exactly 6 movies each for even rows
      const shuffled = [...movies].sort(() => Math.random() - 0.5); // Shuffle movies
      
      const baseCategories = [
        { name: "Trending Now", movies: movies.slice(0, 6) },
        { name: "Action & Adventure", movies: shuffled.filter(m => m.genre && m.genre.includes("Action")).slice(0, 6) },
        { name: "Sci-Fi & Fantasy", movies: shuffled.filter(m => m.genre && (m.genre.includes("Sci-Fi") || m.genre.includes("Adventure") || m.genre.includes("Fantasy"))).slice(0, 6) },
        { name: "Critically Acclaimed", movies: shuffled.filter(m => m.imdb_score >= 7.5).slice(0, 6) },
        { name: "Crime & Thrillers", movies: shuffled.filter(m => m.genre && (m.genre.includes("Thriller") || m.genre.includes("Crime") || m.genre.includes("Action"))).slice(0, 6) },
        { name: "Drama & Biography", movies: shuffled.filter(m => m.genre && (m.genre.includes("Drama") || m.genre.includes("Biography"))).slice(0, 6) }
      ];

      // Ensure each category has exactly 6 movies by padding with random movies if needed
      const evenCategories = baseCategories.map(category => {
        if (category.movies.length < 6) {
          const needed = 6 - category.movies.length;
          const availableMovies = movies.filter(m => !category.movies.includes(m));
          const padding = availableMovies.slice(0, needed);
          category.movies = [...category.movies, ...padding];
        }
        return category;
      });

      setCategories(evenCategories);

      // Try to fetch recommendations in background (non-blocking)
      const fetchRecommendations = async () => {
        try {
          const response = await fetch('http://127.0.0.1:8000/recommendations', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              user_id: 'user123',
              limit: 6
            }),
            timeout: 3000
          });
          
          if (response.ok) {
            const recommendations = await response.json();
            if (recommendations && recommendations.length > 0) {
              setCategories(prev => [
                ...prev,
                { name: "Recommended for you", movies: recommendations }
              ]);
            }
          }
        } catch (error) {
          console.log('Recommendations API not available:', error);
        }
      };

      fetchRecommendations();
    }
  }, [movies]);

  const heroMovies = movies.filter(movie => movie.featured).concat(movies.slice(0, 3));


  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHero((prev) => (prev + 1) % heroMovies.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroMovies.length]);

  const getMoviePosterStyle = (movie) => {
    // Map movie IDs to your high-quality movie posters
    const imageMap = {
      1: '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg',
      2: 'Back-Panther.jpg',
      3: 'Dark-Night.jpg',
      4: 'Fast_Furious_-_Vin_Diesel_-_Dwayne_Rock_Johnson_-_Hollywood_Action_Movie_Poster_fd764ae2-afc5-4ffb-9b1d-b4e8602721b8.jpg',
      5: 'HD-wallpaper-black-adam-movie-poster-2022.jpg',
      6: 'HD-wallpaper-hidden-strike-movie-poster.jpg',
      7: 'wallpapersden.com_oppenheimer-2023-movie-poster_1920x1080.jpg',
      8: 'Interstellar.jpg',
      9: 'dune-black-3840x2160-15808.jpg',
      10: 'desktop-wallpaper-john-wick-chapter-2-2017-movie-poster-background-koexf4-2560x1440-movie.jpg',
      11: 'Star-Wars.jpg',
      12: 'harry-potter-the-order-of-the-phoenix-wallpaper-preview.jpg'
    };
    
    const imageFile = imageMap[movie.id] || '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg';
    const localImageUrl = `/images/movies/${imageFile}`;
    const fallbackUrl = `https://picsum.photos/300/450?random=${movie.id}`;
    
    // Debug logging
    console.log(`Movie: ${movie.title}, ID: ${movie.id}, Image: ${imageFile}`);
    
    return {
      backgroundImage: `url("${localImageUrl}"), url("${fallbackUrl}")`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    };
  };

  const getHeroImageUrl = (movie) => {
    const imageMap = {
      1: '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg',
      2: 'Back-Panther.jpg',
      3: 'Dark-Night.jpg',
      4: 'Fast_Furious_-_Vin_Diesel_-_Dwayne_Rock_Johnson_-_Hollywood_Action_Movie_Poster_fd764ae2-afc5-4ffb-9b1d-b4e8602721b8.jpg',
      5: 'HD-wallpaper-black-adam-movie-poster-2022.jpg',
      6: 'HD-wallpaper-hidden-strike-movie-poster.jpg',
      7: 'wallpapersden.com_oppenheimer-2023-movie-poster_1920x1080.jpg',
      8: 'Interstellar.jpg',
      9: 'dune-black-3840x2160-15808.jpg',
      10: 'desktop-wallpaper-john-wick-chapter-2-2017-movie-poster-background-koexf4-2560x1440-movie.jpg',
      11: 'Harry Potter.jpg',
      12: 'Jurassic-World-Rebirth.jpg',
      13: 'Skyfall.jpg',
      14: 'World-war-Z.jpg',
      15: 'mission-immposible.jpg',
      16: 'HD-wallpaper-rampage-8k-poster-rampage-dwayne-johnson-2018-movies-movies-poster.jpg',
      17: 'Looper.jpg',
      18: 'terminator_dark_fate_movie_poster_4k_8k_hd-3840x2160.jpg'
    };

    const imageFile = imageMap[movie.id] || '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg';
    return `/images/movies/${imageFile}`;
  };

  const MovieCard = ({ movie, isLarge = false }) => {
    const [isHovered, setIsHovered] = useState(false);
    const [imageLoaded, setImageLoaded] = useState(false);
    const [imageError, setImageError] = useState(false);

    const imageMap = {
      1: '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg',
      2: 'Back-Panther.jpg',
      3: 'Dark-Night.jpg',
      4: 'Fast_Furious_-_Vin_Diesel_-_Dwayne_Rock_Johnson_-_Hollywood_Action_Movie_Poster_fd764ae2-afc5-4ffb-9b1d-b4e8602721b8.jpg',
      5: 'HD-wallpaper-black-adam-movie-poster-2022.jpg',
      6: 'HD-wallpaper-hidden-strike-movie-poster.jpg',
      7: 'wallpapersden.com_oppenheimer-2023-movie-poster_1920x1080.jpg',
      8: 'Interstellar.jpg',
      9: 'dune-black-3840x2160-15808.jpg',
      10: 'desktop-wallpaper-john-wick-chapter-2-2017-movie-poster-background-koexf4-2560x1440-movie.jpg',
      11: 'Harry Potter.jpg',
      12: 'Jurassic-World-Rebirth.jpg',
      13: 'Skyfall.jpg',
      14: 'World-war-Z.jpg',
      15: 'mission-immposible.jpg',
      16: 'HD-wallpaper-rampage-8k-poster-rampage-dwayne-johnson-2018-movies-movies-poster.jpg',
      17: 'Looper.jpg',
      18: 'terminator_dark_fate_movie_poster_4k_8k_hd-3840x2160.jpg'
    };

    const imageFile = imageMap[movie.id] || '227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg';
    const imageUrl = `/images/movies/${imageFile}`;
    const fallbackUrl = `https://picsum.photos/300/450?random=${movie.id}`;

    return (
      <div 
        className={`relative flex-shrink-0 cursor-pointer transition-all duration-300 ${
          isLarge ? 'w-80 h-48' : 'w-60 h-36'
        } ${isHovered ? 'scale-105 z-10' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="w-full h-full rounded-lg overflow-hidden shadow-lg relative bg-gray-800">
          {!imageError ? (
            <img 
              src={imageUrl}
              alt={movie.title}
              className="w-full h-full object-cover"
              onLoad={() => setImageLoaded(true)}
              onError={() => {
                console.log(`Failed to load: ${imageUrl}`);
                setImageError(true);
              }}
            />
          ) : (
            <img 
              src={fallbackUrl}
              alt={movie.title}
              className="w-full h-full object-cover"
            />
          )}
          
          {!imageLoaded && !imageError && (
            <div className="absolute inset-0 flex items-center justify-center text-white bg-gray-800">
              <div className="text-center p-4">
                <h3 className="font-bold text-sm mb-1">{movie.title}</h3>
                <p className="text-xs text-gray-300">{movie.year}</p>
              </div>
            </div>
          )}
        </div>
        
        {isHovered && (
          <div className="absolute inset-0 bg-black bg-opacity-80 rounded-lg flex flex-col justify-end p-4 text-white">
            <h3 className="font-bold text-lg mb-2">{movie.title}</h3>
            <p className="text-sm text-gray-300 mb-2">{movie.year} • {movie.rating}</p>
            <p className="text-xs text-gray-400 mb-3 line-clamp-3">{movie.description}</p>
            <div className="flex space-x-2">
              <button className="bg-white text-black px-3 py-1 rounded-full text-sm font-semibold hover:bg-gray-200 transition-colors flex items-center">
                <Play className="w-3 h-3 mr-1" />
                Play
              </button>
              <button className="bg-gray-600 text-white px-3 py-1 rounded-full text-sm hover:bg-gray-500 transition-colors flex items-center">
                <Info className="w-3 h-3 mr-1" />
                Info
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const MovieRow = ({ category }) => {
    const [scrollPosition, setScrollPosition] = useState(0);
    const maxScroll = Math.max(0, category.movies.length - 4) * 260;

    const scroll = (direction) => {
      const scrollAmount = 520;
      const newPosition = direction === 'left' 
        ? Math.max(0, scrollPosition - scrollAmount)
        : Math.min(maxScroll, scrollPosition + scrollAmount);
      setScrollPosition(newPosition);
    };

    return (
      <div className="mb-8">
        <h2 className="text-white text-2xl font-bold mb-4 px-12">{category.name}</h2>
        <div className="relative group px-12">
          {scrollPosition > 0 && (
            <button 
              onClick={() => scroll('left')}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-opacity-70"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          
          <div className="overflow-hidden">
            <div 
              className="flex space-x-4 transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${scrollPosition}px)` }}
            >
              {category.movies.map(movie => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          </div>

          {scrollPosition < maxScroll && (
            <button 
              onClick={() => scroll('right')}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-opacity-70"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}
        </div>
      </div>
    );
  };

  const currentHeroMovie = heroMovies.length > 0 ? heroMovies[currentHero] : null;

  if (!currentHeroMovie) {
    return <div className="bg-black min-h-screen flex justify-center items-center text-white">Loading...</div>;
  }

  return (
    <div className="bg-black min-h-screen text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-transparent">
        <div className="flex items-center justify-between px-12 py-4">
          <div className="flex items-center space-x-8">
            <div className="text-red-600 text-3xl font-bold">NETFLIX</div>
            <nav className="hidden md:flex space-x-6">
              <a href="/" className="text-white hover:text-gray-300 transition-colors">Home</a>
              <a href="/" className="text-gray-400 hover:text-white transition-colors">TV Shows</a>
              <a href="/" className="text-gray-400 hover:text-white transition-colors">Movies</a>
              <a href="/" className="text-gray-400 hover:text-white transition-colors">New & Popular</a>
              <a href="/" className="text-gray-400 hover:text-white transition-colors">My List</a>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <Search className="w-5 h-5 text-white cursor-pointer hover:text-gray-300" />
            <Bell className="w-5 h-5 text-white cursor-pointer hover:text-gray-300" />
            <User className="w-8 h-8 bg-red-600 rounded p-1 cursor-pointer hover:bg-red-700" />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-screen">
        <div 
          className="absolute inset-0"
          style={{ 
            backgroundImage: `url(${getHeroImageUrl(currentHeroMovie)})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
          <div className="absolute inset-0" style={{ background: currentHeroMovie.backdrop_gradient, opacity: 0.3 }}></div>
        </div>
        
        <div className="relative z-10 flex items-center h-full px-12">
          <div className="max-w-2xl">
            <h1 className="text-6xl font-bold mb-4 drop-shadow-lg">
              {currentHeroMovie.title}
            </h1>
            <p className="text-xl mb-6 drop-shadow-lg">
              {currentHeroMovie.description}
            </p>
            <div className="flex space-x-4">
              <button className="bg-white text-black px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-200 transition-colors flex items-center">
                <Play className="w-5 h-5 mr-2" />
                Play
              </button>
              <button className="bg-gray-600 bg-opacity-70 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-opacity-90 transition-all flex items-center">
                <Info className="w-5 h-5 mr-2" />
                More Info
              </button>
            </div>
          </div>
        </div>

        {/* Hero Navigation Dots */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroMovies.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentHero(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentHero ? 'bg-white' : 'bg-gray-500 hover:bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content Rows */}
      <div className="relative z-10 mt-16 pb-16">
        {categories.map((category, index) => (
          <MovieRow key={index} category={category} />
        ))}
      </div>

      {/* Footer */}
      <footer className="bg-black bg-opacity-90 text-gray-400 py-16 px-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white font-semibold mb-4">Questions? Contact us.</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/" className="hover:underline">FAQ</a></li>
                <li><a href="/" className="hover:underline">Help Center</a></li>
                <li><a href="/" className="hover:underline">Account</a></li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2 text-sm mt-8 md:mt-0">
                <li><a href="/" className="hover:underline">Media Center</a></li>
                <li><a href="/" className="hover:underline">Relations</a></li>
                <li><a href="/" className="hover:underline">Investor Relations</a></li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2 text-sm mt-8 md:mt-0">
                <li><a href="/" className="hover:underline">Ways to Watch</a></li>
                <li><a href="/" className="hover:underline">Terms of Use</a></li>
                <li><a href="/" className="hover:underline">Privacy</a></li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2 text-sm mt-8 md:mt-0">
                <li><a href="/" className="hover:underline">Cookie Preferences</a></li>
                <li><a href="/" className="hover:underline">Corporate Information</a></li>
                <li><a href="/" className="hover:underline">Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 text-sm">
            © 2024 Netflix Clone. This is a demo application.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default NetflixApp;
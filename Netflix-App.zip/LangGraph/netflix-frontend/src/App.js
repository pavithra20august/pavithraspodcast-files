import NetflixApp from './NetflixApp';

function App() {
  return <NetflixApp />;
}

export default App;

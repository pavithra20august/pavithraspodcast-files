# Netflix Backend with LangGraph, ChromaDB, and Gemini API
# requirements.txt:
# fastapi==0.104.1
# uvicorn==0.24.0
# chromadb==0.4.15
# langgraph==0.0.40
# langchain==0.1.0
# langchain-google-genai==0.0.6
# google-generativeai==0.3.2
# pydantic==2.5.0
# python-multipart==0.0.6
# python-dotenv==1.0.0

import os
import uuid
import json
from typing import List, Dict, Any, Optional
from datetime import datetime
from enum import Enum

import chromadb
from chromadb.config import Settings
import google.generativeai as genai
from langchain_google_genai import GoogleGenerativeAI
from langgraph.graph import StateGraph, END
from langchain.schema import BaseMessage, HumanMessage, AIMessage

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(title="Netflix Backend API", version="1.0.0")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Gemini AI
genai.configure(api_key=os.getenv("GEMINI_API_KEY", "your-gemini-api-key"))
llm = GoogleGenerativeAI(model="gemini-2.5-pro", google_api_key=os.getenv("GEMINI_API_KEY"))

# Initialize ChromaDB
chroma_client = chromadb.PersistentClient(path="./chroma_db")
movie_collection = chroma_client.get_or_create_collection(
    name="movies",
    metadata={"hnsw:space": "cosine"}
)
user_collection = chroma_client.get_or_create_collection(
    name="user_preferences",
    metadata={"hnsw:space": "cosine"}
)

# Data Models
class Genre(str, Enum):
    ACTION = "Action"
    ADVENTURE = "Adventure"
    COMEDY = "Comedy"
    DRAMA = "Drama"
    HORROR = "Horror"
    SCI_FI = "Sci-Fi"
    THRILLER = "Thriller"
    ROMANCE = "Romance"
    CRIME = "Crime"
    BIOGRAPHY = "Biography"

class Movie(BaseModel):
    id: int
    title: str
    genre: List[str]
    year: int
    rating: str
    description: str
    poster_url: Optional[str] = None
    backdrop_gradient: str
    duration: int = 120  # minutes
    imdb_score: float = 7.0
    netflix_score: int = 85
    cast: List[str] = []
    director: str = "Unknown"
    featured: bool = False

class UserPreference(BaseModel):
    user_id: str
    watched_movies: List[int] = []
    liked_genres: List[str] = []
    disliked_genres: List[str] = []
    preferred_rating: Optional[str] = None
    watch_history: List[Dict[str, Any]] = []

class RecommendationRequest(BaseModel):
    user_id: str
    genre_preference: Optional[str] = None
    limit: int = Field(default=10, le=50)

class WatchHistoryItem(BaseModel):
    user_id: str
    movie_id: int
    watched_at: datetime = Field(default_factory=datetime.now)
    watch_duration: int  # seconds watched
    rating: Optional[int] = None  # 1-5 stars

# Sample movie data
SAMPLE_MOVIES = [
    Movie(
        id=1,
        title="Avengers: Endgame",
        genre=["Action", "Adventure"],
        year=2019,
        rating="PG-13",
        description="After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more.",
        poster_url="/images/movies/227405-avengers-endgame-2019-poster-wallpaper-avengers-movie-posters.jpg",
        backdrop_gradient="linear-gradient(135deg, #1a3c5c 0%, #2d5a8a 100%)",
        duration=181,
        imdb_score=8.4,
        cast=["Robert Downey Jr.", "Chris Evans", "Scarlett Johansson"],
        director="Russo Brothers",
        featured=True
    ),
    Movie(
        id=2,
        title="Black Panther",
        genre=["Action", "Adventure"],
        year=2018,
        rating="PG-13",
        description="T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future.",
        poster_url="/images/movies/Back-Panther.jpg",
        backdrop_gradient="linear-gradient(135deg, #2a1a3d 0%, #4a2d6b 100%)",
        duration=134,
        imdb_score=7.3,
        cast=["Chadwick Boseman", "Michael B. Jordan", "Lupita Nyong'o"],
        director="Ryan Coogler"
    ),
    Movie(
        id=3,
        title="The Dark Knight",
        genre=["Action", "Crime", "Drama"],
        year=2008,
        rating="PG-13",
        description="When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
        poster_url="/images/movies/Dark-Night.jpg",
        backdrop_gradient="linear-gradient(135deg, #1a1a1a 0%, #3d3d3d 100%)",
        duration=152,
        imdb_score=9.0,
        cast=["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
        director="Christopher Nolan"
    ),
    Movie(
        id=4,
        title="Sicario",
        genre=["Crime", "Thriller"],
        year=2015,
        rating="R",
        description="An idealistic FBI agent is enlisted by a government task force to aid in the escalating war against drugs at the border area between the U.S. and Mexico.",
        backdrop_gradient="linear-gradient(135deg, #3d2a1a 0%, #6b4423 100%)",
        duration=121,
        imdb_score=7.7,
        cast=["Emily Blunt", "Benicio Del Toro", "Josh Brolin"],
        director="Denis Villeneuve"
    ),
    Movie(
        id=5,
        title="Black Panther",
        genre=["Action", "Adventure"],
        year=2018,
        rating="PG-13",
        description="T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future.",
        backdrop_gradient="linear-gradient(135deg, #2a1a3d 0%, #4a2d6b 100%)",
        duration=134,
        imdb_score=7.3,
        cast=["Chadwick Boseman", "Michael B. Jordan", "Lupita Nyong'o"],
        director="Ryan Coogler"
    ),
    Movie(
        id=6,
        title="Guardians of the Galaxy",
        genre=["Action", "Comedy"],
        year=2014,
        rating="PG-13",
        description="A group of intergalactic criminals must pull together to stop a fanatical warrior with plans to purge the universe.",
        backdrop_gradient="linear-gradient(135deg, #3d1a5c 0%, #6b2d8a 100%)",
        duration=121,
        imdb_score=8.0,
        cast=["Chris Pratt", "Zoe Saldana", "Dave Bautista"],
        director="James Gunn"
    ),
    Movie(
        id=7,
        title="Oppenheimer",
        genre=["Biography", "Drama"],
        year=2023,
        rating="R",
        description="The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.",
        backdrop_gradient="linear-gradient(135deg, #5c3d1a 0%, #8a6b2d 100%)",
        duration=180,
        imdb_score=8.4,
        cast=["Cillian Murphy", "Emily Blunt", "Robert Downey Jr."],
        director="Christopher Nolan"
    ),
    Movie(
        id=8,
        title="The Avengers",
        genre=["Action", "Adventure"],
        year=2012,
        rating="PG-13",
        description="Earth's mightiest heroes must come together and learn to fight as a team if they are going to stop the mischievous Loki and his alien army from enslaving humanity.",
        backdrop_gradient="linear-gradient(135deg, #1a3d5c 0%, #2d6b8a 100%)",
        duration=143,
        imdb_score=8.0,
        cast=["Robert Downey Jr.", "Chris Evans", "Scarlett Johansson"],
        director="Joss Whedon"
    ),
    Movie(
        id=9,
        title="Bullet Train",
        genre=["Action", "Comedy"],
        year=2022,
        rating="R",
        description="Five assassins aboard a fast moving bullet train find out their missions have something in common.",
        backdrop_gradient="linear-gradient(135deg, #5c1a3d 0%, #8a2d6b 100%)",
        duration=127,
        imdb_score=7.3,
        cast=["Brad Pitt", "Joey King", "Aaron Taylor-Johnson"],
        director="David Leitch"
    ),
    Movie(
        id=10,
        title="Jaws",
        genre=["Thriller", "Horror"],
        year=1975,
        rating="PG",
        description="When a killer shark unleashes chaos on a beach community off Cape Cod, it's up to a local sheriff, a marine biologist, and an old seafarer to hunt the beast down.",
        backdrop_gradient="linear-gradient(135deg, #1a4a5c 0%, #2d7a8a 100%)",
        duration=124,
        imdb_score=8.1,
        cast=["Roy Scheider", "Robert Shaw", "Richard Dreyfuss"],
        director="Steven Spielberg"
    ),
    Movie(
        id=11,
        title="Harry Potter and the Philosopher's Stone",
        genre=["Adventure", "Family", "Fantasy"],
        year=2001,
        rating="PG",
        description="An orphaned boy enrolls in a school of wizardry, where he learns the truth about himself, his family and the terrible evil that haunts the magical world.",
        poster_url="/images/movies/Harry Potter.jpg",
        backdrop_gradient="linear-gradient(135deg, #2d1a3d 0%, #5c2d6b 100%)",
        duration=152,
        imdb_score=7.6,
        cast=["Daniel Radcliffe", "Rupert Grint", "Emma Watson"],
        director="Chris Columbus"
    ),
    Movie(
        id=12,
        title="Jurassic World: Rebirth",
        genre=["Action", "Adventure", "Sci-Fi"],
        year=2025,
        rating="PG-13",
        description="An expedition braves dangerous proto-historic waters in order to save and study the magnificent creatures of the ancient world.",
        poster_url="/images/movies/Jurassic-World-Rebirth.jpg",
        backdrop_gradient="linear-gradient(135deg, #3d2a1a 0%, #6b4423 100%)",
        duration=140,
        imdb_score=7.1,
        cast=["Scarlett Johansson", "Jonathan Bailey", "Mahershala Ali"],
        director="Gareth Edwards",
        featured=True
    ),
    Movie(
        id=13,
        title="Skyfall",
        genre=["Action", "Adventure", "Thriller"],
        year=2012,
        rating="PG-13",
        description="James Bond's loyalty to M is tested when her past comes back to haunt her. When MI6 comes under attack, 007 must track down and destroy the threat.",
        poster_url="/images/movies/Skyfall.jpg",
        backdrop_gradient="linear-gradient(135deg, #1a3d5c 0%, #2d6b8a 100%)",
        duration=143,
        imdb_score=7.8,
        cast=["Daniel Craig", "Javier Bardem", "Naomie Harris"],
        director="Sam Mendes"
    ),
    Movie(
        id=14,
        title="World War Z",
        genre=["Action", "Drama", "Horror"],
        year=2013,
        rating="PG-13",
        description="Former United Nations employee Gerry Lane traverses the world in a race against time to stop a zombie pandemic.",
        poster_url="/images/movies/World-war-Z.jpg",
        backdrop_gradient="linear-gradient(135deg, #2d1b1b 0%, #5c1a1a 100%)",
        duration=116,
        imdb_score=7.0,
        cast=["Brad Pitt", "Mireille Enos", "Daniella Kertesz"],
        director="Marc Forster"
    ),
    Movie(
        id=15,
        title="Mission: Impossible",
        genre=["Action", "Adventure", "Thriller"],
        year=1996,
        rating="PG-13",
        description="An American agent, under false suspicion of disloyalty, must discover and expose the real spy without the help of his organization.",
        poster_url="/images/movies/mission-immposible.jpg",
        backdrop_gradient="linear-gradient(135deg, #3d2a1a 0%, #6b4423 100%)",
        duration=110,
        imdb_score=7.2,
        cast=["Tom Cruise", "Jon Voight", "Emmanuelle Béart"],
        director="Brian De Palma"
    ),
    Movie(
        id=16,
        title="Rampage",
        genre=["Action", "Adventure", "Sci-Fi"],
        year=2018,
        rating="PG-13",
        description="When three different animals become infected with a dangerous pathogen, a primatologist and a geneticist team up to stop them.",
        poster_url="/images/movies/HD-wallpaper-rampage-8k-poster-rampage-dwayne-johnson-2018-movies-movies-poster.jpg",
        backdrop_gradient="linear-gradient(135deg, #2d1b1b 0%, #5c1a1a 100%)",
        duration=107,
        imdb_score=6.1,
        cast=["Dwayne Johnson", "Naomie Harris", "Malin Akerman"],
        director="Brad Peyton"
    ),
    Movie(
        id=17,
        title="Looper",
        genre=["Action", "Drama", "Sci-Fi"],
        year=2012,
        rating="R",
        description="In 2074, when the mob wants to get rid of someone, the target is sent into the past, where a hired gun awaits - someone like Joe.",
        poster_url="/images/movies/Looper.jpg",
        backdrop_gradient="linear-gradient(135deg, #1a3c5c 0%, #2d5a8a 100%)",
        duration=119,
        imdb_score=7.4,
        cast=["Joseph Gordon-Levitt", "Bruce Willis", "Emily Blunt"],
        director="Rian Johnson"
    ),
    Movie(
        id=18,
        title="Terminator: Dark Fate",
        genre=["Action", "Adventure", "Sci-Fi"],
        year=2019,
        rating="R",
        description="An augmented human and Sarah Connor must stop an advanced liquid Terminator from hunting down a young girl.",
        poster_url="/images/movies/terminator_dark_fate_movie_poster_4k_8k_hd-3840x2160.jpg",
        backdrop_gradient="linear-gradient(135deg, #1a1a3d 0%, #3d3d6b 100%)",
        duration=128,
        imdb_score=6.2,
        cast=["Linda Hamilton", "Arnold Schwarzenegger", "Mackenzie Davis"],
        director="Tim Miller",
        featured=True
    )
]

# Database Operations
class DatabaseManager:
    def __init__(self):
        self.initialize_database()
    
    def initialize_database(self):
        """Initialize database with sample data"""
        try:
            # Check if movies already exist
            if movie_collection.count() == 0:
                # Add sample movies to ChromaDB
                for movie in SAMPLE_MOVIES:
                    self.add_movie_to_db(movie)
                print("Database initialized with sample movies")
        except Exception as e:
            print(f"Error initializing database: {e}")
    
    def add_movie_to_db(self, movie: Movie):
        """Add movie to ChromaDB with embeddings"""
        movie_text = f"{movie.title} {' '.join(movie.genre)} {movie.description} {movie.director} {' '.join(movie.cast)}"
        
        metadata = movie.model_dump()
        metadata['genre'] = ','.join(metadata.get('genre', []))
        metadata['cast'] = ','.join(metadata.get('cast', []))

        movie_collection.add(
            documents=[movie_text],
            metadatas=[metadata],
            ids=[str(movie.id)]
        )
    
    def _parse_movie_metadata(self, metadata: Dict[str, Any]) -> Movie:
        """Parse metadata from ChromaDB back into a Movie object."""
        if isinstance(metadata.get('genre'), str):
            metadata['genre'] = metadata['genre'].split(',') if metadata['genre'] else []
        if isinstance(metadata.get('cast'), str):
            metadata['cast'] = metadata['cast'].split(',') if metadata['cast'] else []
        return Movie(**metadata)

    def get_movie_by_id(self, movie_id: int) -> Optional[Movie]:
        """Get movie by ID"""
        try:
            result = movie_collection.get(ids=[str(movie_id)])
            if result['metadatas']:
                return self._parse_movie_metadata(result['metadatas'][0])
            return None
        except Exception:
            return None
    
    def search_movies_by_text(self, query: str, limit: int = 10) -> List[Movie]:
        """Search movies using vector similarity"""
        try:
            results = movie_collection.query(
                query_texts=[query],
                n_results=limit
            )
            movies = []
            for metadata in results['metadatas'][0]:
                movies.append(self._parse_movie_metadata(metadata))
            return movies
        except Exception:
            return []
    
    def get_movies_by_genre(self, genre: str, limit: int = 10) -> List[Movie]:
        """Get movies filtered by genre"""
        try:
            results = movie_collection.get()
            filtered_movies = []
            
            for metadata in results['metadatas']:
                movie = self._parse_movie_metadata(metadata)
                if genre.lower() in [g.lower() for g in movie.genre]:
                    filtered_movies.append(movie)
            
            return filtered_movies[:limit]
        except Exception:
            return []
    
    def add_user_preference(self, user_pref: UserPreference):
        """Add or update user preferences"""
        try:
            pref_text = f"User likes: {' '.join(user_pref.liked_genres)} dislikes: {' '.join(user_pref.disliked_genres)}"
            
            metadata = user_pref.model_dump()
            metadata['watched_movies'] = json.dumps(metadata.get('watched_movies', []))
            metadata['liked_genres'] = ','.join(metadata.get('liked_genres', []))
            metadata['disliked_genres'] = ','.join(metadata.get('disliked_genres', []))
            metadata['watch_history'] = json.dumps(metadata.get('watch_history', []))

            user_collection.upsert(
                documents=[pref_text],
                metadatas=[metadata],
                ids=[user_pref.user_id]
            )
        except Exception as e:
            print(f"Error adding user preference: {e}")
    
    def get_user_preference(self, user_id: str) -> Optional[UserPreference]:
        """Get user preferences"""
        try:
            result = user_collection.get(ids=[user_id])
            if result['metadatas']:
                metadata = result['metadatas'][0]
                if isinstance(metadata.get('watched_movies'), str):
                    metadata['watched_movies'] = json.loads(metadata['watched_movies'])
                if isinstance(metadata.get('liked_genres'), str):
                    metadata['liked_genres'] = metadata['liked_genres'].split(',') if metadata['liked_genres'] else []
                if isinstance(metadata.get('disliked_genres'), str):
                    metadata['disliked_genres'] = metadata['disliked_genres'].split(',') if metadata['disliked_genres'] else []
                if isinstance(metadata.get('watch_history'), str):
                    metadata['watch_history'] = json.loads(metadata['watch_history'])
                return UserPreference(**metadata)
            return None
        except Exception:
            return None

db_manager = DatabaseManager()

# LangGraph Recommendation System
class RecommendationState(BaseModel):
    user_id: str
    user_preferences: Optional[UserPreference] = None
    genre_filter: Optional[str] = None
    candidate_movies: List[Movie] = []
    gemini_recommendations: List[Dict[str, Any]] = []
    final_recommendations: List[Movie] = []
    messages: List[BaseMessage] = []

def get_user_preferences(state: RecommendationState) -> RecommendationState:
    """Node: Get user preferences from database"""
    user_pref = db_manager.get_user_preference(state.user_id)
    if not user_pref:
        # Create default preferences for new user
        user_pref = UserPreference(user_id=state.user_id)
        db_manager.add_user_preference(user_pref)
    
    state.user_preferences = user_pref
    state.messages.append(HumanMessage(content=f"Retrieved preferences for user {state.user_id}"))
    return state

def get_candidate_movies(state: RecommendationState) -> RecommendationState:
    """Node: Get candidate movies based on genre or user history"""
    if state.genre_filter:
        candidates = db_manager.get_movies_by_genre(state.genre_filter, 20)
    else:
        # Get diverse set of movies
        candidates = []
        for movie in SAMPLE_MOVIES:
            candidates.append(movie)
    
    # Filter out already watched movies
    if state.user_preferences and state.user_preferences.watched_movies:
        candidates = [m for m in candidates if m.id not in state.user_preferences.watched_movies]
    
    state.candidate_movies = candidates
    state.messages.append(HumanMessage(content=f"Found {len(candidates)} candidate movies"))
    return state

def gemini_analyze_and_recommend(state: RecommendationState) -> RecommendationState:
    """Node: Use Gemini to analyze user preferences and recommend movies"""
    # Always start with fallback recommendations to ensure we have something
    fallback_recommendations = [
        {
            "movie_title": movie.title,
            "recommendation_score": 0.8,
            "reason": f"Popular {', '.join(movie.genre)} movie with {movie.imdb_score} IMDB rating"
        }
        for movie in state.candidate_movies[:5]
    ]
    
    try:
        # Skip Gemini AI for now and use intelligent fallback
        print("Using intelligent movie recommendations based on movie data")
        
        # Sort movies by IMDB score and popularity
        sorted_movies = sorted(state.candidate_movies, key=lambda x: x.imdb_score, reverse=True)
        
        # Create better recommendations based on movie attributes
        state.gemini_recommendations = [
            {
                "movie_title": movie.title,
                "recommendation_score": min(movie.imdb_score / 10.0, 1.0),
                "reason": f"Highly rated {', '.join(movie.genre)} film ({movie.imdb_score}/10 IMDB) directed by {movie.director}"
            }
            for movie in sorted_movies[:5]
        ]
        
        state.messages.append(AIMessage(content=f"Generated {len(state.gemini_recommendations)} intelligent recommendations"))
        
    except Exception as e:
        print(f"Error in recommendation generation: {e}")
        state.gemini_recommendations = fallback_recommendations
    
    return state

def finalize_recommendations(state: RecommendationState) -> RecommendationState:
    """Node: Finalize and rank recommendations"""
    final_movies = []
    
    for gem_rec in state.gemini_recommendations:
        # Find matching movie
        for movie in state.candidate_movies:
            if movie.title.lower() == gem_rec['movie_title'].lower():
                final_movies.append(movie)
                break
    
    # If we don't have enough, add some high-rated movies
    if len(final_movies) < 5:
        remaining_movies = [m for m in state.candidate_movies if m not in final_movies]
        remaining_movies.sort(key=lambda x: x.imdb_score, reverse=True)
        final_movies.extend(remaining_movies[:5-len(final_movies)])
    
    state.final_recommendations = final_movies
    state.messages.append(AIMessage(content=f"Finalized {len(final_movies)} recommendations"))
    return state

# Create LangGraph workflow
def create_recommendation_graph():
    graph = StateGraph(RecommendationState)
    
    # Add nodes
    graph.add_node("get_user_preferences", get_user_preferences)
    graph.add_node("get_candidate_movies", get_candidate_movies)
    graph.add_node("gemini_analyze", gemini_analyze_and_recommend)
    graph.add_node("finalize_recommendations", finalize_recommendations)
    
    # Add edges
    graph.add_edge("get_user_preferences", "get_candidate_movies")
    graph.add_edge("get_candidate_movies", "gemini_analyze")
    graph.add_edge("gemini_analyze", "finalize_recommendations")
    graph.add_edge("finalize_recommendations", END)
    
    # Set entry point
    graph.set_entry_point("get_user_preferences")
    
    return graph.compile()

recommendation_graph = create_recommendation_graph()

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Netflix Backend API", "version": "1.0.0"}

@app.get("/movies", response_model=List[Movie])
async def get_all_movies():
    """Get all available movies"""
    return SAMPLE_MOVIES

@app.get("/movies/{movie_id}", response_model=Movie)
async def get_movie(movie_id: int):
    """Get specific movie by ID"""
    movie = db_manager.get_movie_by_id(movie_id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    return movie

@app.get("/movies/genre/{genre}", response_model=List[Movie])
async def get_movies_by_genre(genre: str, limit: int = Query(10, le=50)):
    """Get movies by genre"""
    movies = db_manager.get_movies_by_genre(genre, limit)
    return movies

@app.get("/search/movies", response_model=List[Movie])
async def search_movies(q: str, limit: int = Query(10, le=50)):
    """Search movies by text"""
    movies = db_manager.search_movies_by_text(q, limit)
    return movies

@app.post("/users/{user_id}/preferences")
async def update_user_preferences(user_id: str, preferences: UserPreference):
    """Update user preferences"""
    preferences.user_id = user_id
    db_manager.add_user_preference(preferences)
    return {"message": "User preferences updated successfully"}

@app.get("/users/{user_id}/preferences", response_model=UserPreference)
async def get_user_preferences_endpoint(user_id: str):
    """Get user preferences"""
    preferences = db_manager.get_user_preference(user_id)
    if not preferences:
        # Return default preferences
        return UserPreference(user_id=user_id)
    return preferences

@app.post("/users/{user_id}/watch-history")
async def add_watch_history(user_id: str, watch_item: WatchHistoryItem):
    """Add item to watch history"""
    watch_item.user_id = user_id
    
    # Update user preferences
    user_pref = db_manager.get_user_preference(user_id)
    if not user_pref:
        user_pref = UserPreference(user_id=user_id)
    
    # Add to watched movies if not already there
    if watch_item.movie_id not in user_pref.watched_movies:
        user_pref.watched_movies.append(watch_item.movie_id)
    
    # Add to watch history
    user_pref.watch_history.append(watch_item.model_dump())
    
    # Update liked genres based on rating
    if watch_item.rating and watch_item.rating >= 4:
        movie = db_manager.get_movie_by_id(watch_item.movie_id)
        if movie:
            for genre in movie.genre:
                if genre not in user_pref.liked_genres:
                    user_pref.liked_genres.append(genre)
    
    db_manager.add_user_preference(user_pref)
    return {"message": "Watch history updated successfully"}

@app.post("/recommendations", response_model=List[Movie])
async def get_recommendations(request: RecommendationRequest):
    """Get AI-powered movie recommendations using LangGraph"""
    try:
        # Initialize state
        state = RecommendationState(
            user_id=request.user_id,
            genre_filter=request.genre_preference
        )
        
        # Run the recommendation graph
        result = recommendation_graph.invoke(state.model_dump())
        
        # Extract final recommendations
        final_state = RecommendationState(**result)
        recommendations = final_state.final_recommendations[:request.limit]
        
        return recommendations
        
    except Exception as e:
        print(f"Error in recommendations: {e}")
        # Fallback to simple recommendations
        if request.genre_preference:
            return db_manager.get_movies_by_genre(request.genre_preference, request.limit)
        else:
            return SAMPLE_MOVIES[:request.limit]

@app.get("/categories")
async def get_categories():
    """Get movie categories for the frontend"""
    return {
        "trending_now": SAMPLE_MOVIES[:6],
        "action_adventure": [m for m in SAMPLE_MOVIES if "Action" in m.genre or "Adventure" in m.genre][:5],
        "sci_fi_fantasy": [m for m in SAMPLE_MOVIES if "Sci-Fi" in m.genre or "Horror" in m.genre][:4],
        "critically_acclaimed": sorted(SAMPLE_MOVIES, key=lambda x: x.imdb_score, reverse=True)[:4],
        "thrillers": [m for m in SAMPLE_MOVIES if "Thriller" in m.genre or "Crime" in m.genre][:4]
    }

@app.get("/featured")
async def get_featured_movies():
    """Get featured movies for hero section"""
    featured = [m for m in SAMPLE_MOVIES if m.featured]
    if not featured:
        featured = SAMPLE_MOVIES[:3]
    return featured

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

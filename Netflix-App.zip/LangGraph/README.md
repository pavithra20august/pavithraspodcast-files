# Netflix Clone with LangGraph & ChromaDB

A full-stack Netflix clone featuring AI-powered movie recommendations using LangGraph, ChromaDB vector database, and Gemini AI.

## 🚀 Features

- **AI-Powered Recommendations**: Using LangGraph orchestration with ChromaDB vector search
- **Movie Catalog**: 18 high-quality movies with authentic posters
- **Netflix-Style UI**: Responsive interface with Tailwind CSS
- **Vector Database**: ChromaDB for intelligent movie matching
- **LangGraph Workflow**: Multi-step recommendation pipeline
- **Real-time Hero Section**: Rotating featured movies

## 📁 Project Structure

```
/LangGraph/
├── netflix-backend.py          # FastAPI backend with LangGraph
├── requirements.txt            # Python dependencies
├── chroma_db/                  # ChromaDB vector database
└── netflix-frontend/           # React frontend application
    ├── src/
    │   ├── App.js             # Main React app
    │   ├── NetflixApp.js      # Netflix UI component
    │   ├── index.js           # React entry point
    │   └── index.css          # Tailwind CSS styles
    ├── public/
    │   ├── images/movies/     # Movie poster collection (18 movies)
    │   └── index.html         # HTML template
    ├── package.json           # Node.js dependencies
    └── tailwind.config.js     # Tailwind CSS configuration
```

## 🛠️ Installation & Setup

### Backend Setup
```bash
# Install Python dependencies
pip3 install -r requirements.txt

# Run the backend server
python3 netflix-backend.py
```
Server runs on: `http://localhost:8000`

### Frontend Setup
```bash
# Navigate to frontend directory
cd netflix-frontend

# Install dependencies
npm install

# Start development server
npm start
```
Frontend runs on: `http://localhost:3000`

## 🎬 Movie Catalog

**18 Movies with High-Quality Posters:**
- Avengers: Endgame (Featured)
- Black Panther
- The Dark Knight
- Fast & Furious
- Black Adam
- Hidden Strike
- Oppenheimer
- Interstellar
- Dune
- John Wick: Chapter 2
- Harry Potter
- Jurassic World: Rebirth (Featured)
- Skyfall
- World War Z
- Mission: Impossible
- Rampage
- Looper
- Terminator: Dark Fate (Featured)

## 🧠 LangGraph Architecture

**Recommendation Pipeline:**
1. **Get User Preferences** - Retrieve from ChromaDB
2. **Get Candidate Movies** - Filter by genre/preferences
3. **Intelligent Analysis** - Sort by IMDB ratings and attributes
4. **Finalize Recommendations** - Return top-rated matches

## 🔧 API Endpoints

- `GET /movies` - Get all movies
- `GET /movies/{id}` - Get specific movie
- `GET /movies/genre/{genre}` - Filter by genre
- `POST /recommendations` - AI-powered recommendations
- `GET /categories` - Grouped movie categories
- `POST /users/{id}/preferences` - Update user preferences

## 🎯 Technologies Used

**Backend:**
- FastAPI (Python web framework)
- LangGraph (AI workflow orchestration)
- ChromaDB (Vector database)
- Gemini AI (Language model)
- Pydantic (Data validation)

**Frontend:**
- React (JavaScript framework)
- Tailwind CSS (Styling)
- Lucide React (Icons)
- Responsive design

## 📊 Database

**ChromaDB Collections:**
- `movies` - Vector embeddings for movie similarity
- `user_preferences` - User behavior and preferences

## 🚦 Running the Application

1. **Start Backend**: `python3 netflix-backend.py`
2. **Start Frontend**: `cd netflix-frontend && npm start`
3. **Open Browser**: Navigate to `http://localhost:3000`

## 🎨 Features Showcase

- ✅ Hero section with rotating featured movies
- ✅ 6 movie categories with horizontal scrolling
- ✅ Hover effects with movie details
- ✅ AI-powered "Recommended for you" section
- ✅ Responsive design for all screen sizes
- ✅ Professional Netflix-style interface

---

**Built with ❤️ using LangGraph, ChromaDB, and React**
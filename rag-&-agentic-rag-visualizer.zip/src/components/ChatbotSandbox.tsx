import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, Bot, User, Sparkles, AlertCircle, RefreshCw, Cpu, Database, 
  CheckCircle2, ArrowRight, CornerDownRight, MessageSquare, ListFilter, PlayCircle
} from 'lucide-react';
import { Dataset, RAGStep, SimulationResult } from '../types';
import { DATASETS } from '../data/datasets';

interface Message {
  id: string;
  sender: 'user' | 'agent' | 'system';
  text: string;
  pipelineType?: 'standard' | 'agentic';
  executionTimeMs?: number;
  costEstimateCents?: number;
  steps?: RAGStep[];
  citations?: string[];
  isLoading?: boolean;
}

interface ChatbotSandboxProps {
  selectedDatasetId: string;
  onDatasetChange: (id: string) => void;
}

export function ChatbotSandbox({ selectedDatasetId, onDatasetChange }: ChatbotSandboxProps) {
  const [pipelineType, setPipelineType] = useState<'standard' | 'agentic'>('agentic');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [expandedTraceId, setExpandedTraceId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const activeDataset = DATASETS.find(d => d.id === selectedDatasetId) || DATASETS[0];

  // Quick prompt suggestions based on selected dataset
  const getSuggestions = () => {
    switch (selectedDatasetId) {
      case 'health-benefits':
        return [
          { label: "Mental health August eligibility", text: "Can I get reimbursed for a specialized cognitive mental health assessment in August under our corporate policy?" },
          { label: "Standard claim limit & timeline", text: "What are the standard reimbursement limits and claim windows for therapy?" },
          { label: "Rider 12B pre-approval rule", text: "What is the pre-approval requirement and deadline for Rider 12B?" }
        ];
      case 'quantum-vc':
        return [
          { label: "Transmon vs Flux-9 times", text: "Coherence times (T2) are how long for standard transmons compared to the Flux-9 prototype?" },
          { label: "Flux quanta ranges", text: "What are the required tuned microwave flux-bias quanta ranges for the Flux-9?" },
          { label: "Milestones in Q4 2026", text: "When is AetherQ hardware transitioning from Transmons to Flux-9, and what are the fidelity changes?" }
        ];
      case 'ev-safety':
        return [
          { label: "Brake caliper winter issue", text: "Is there a lag in emergency brake pressure for vehicles under slushy ice? What is the fix?" },
          { label: "Battery heating rules", text: "What ambient temperature triggers the lithium cell pre-heating protocols?" },
          { label: "Bulletin number for brakes", text: "What is the technical recall bulletin code for applying silicon dust-jackets?" }
        ];
      default:
        return [];
    }
  };

  // Pre-populate welcome message on mount or dataset change
  useEffect(() => {
    setMessages([
      {
        id: 'welcome',
        sender: 'agent',
        text: `こんにちは! I am your interactive **RAG Retrieval Agent** connected live to the **${activeDataset.name}** database context.\n\nYou can input any inquiry regarding this database in the prompt box below, and watch how Standard vs. Agentic control loops route, optimize, retrieve, and cross-examine details.`,
        pipelineType: 'agentic',
        steps: []
      }
    ]);
  }, [selectedDatasetId]);

  // Scroll to bottom when messages are appended
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Offline high fidelity simulator fallback
  const getOfflineSimulation = (query: string, mode: 'standard' | 'agentic'): SimulationResult => {
    const dataset = activeDataset;
    const lowerQuery = query.toLowerCase();

    // Word matcher for scores
    const scoredChunks = dataset.chunks.map(chunk => {
      const words = lowerQuery.split(/\s+/);
      let matchCount = 0;
      words.forEach(word => {
        if (word.length > 2 && chunk.content.toLowerCase().includes(word)) {
          matchCount++;
        }
      });

      // Boosts
      if (dataset.id === 'health-benefits') {
        if (lowerQuery.includes('august') || lowerQuery.includes('september')) {
          if (chunk.source.includes('Rider-12B')) matchCount += 1.5;
        }
      } else if (dataset.id === 'quantum-vc') {
        if (lowerQuery.includes('better') || lowerQuery.includes('coherence') || lowerQuery.includes('fluxonium')) {
          if (chunk.source.includes('Fluxonium')) matchCount += 2;
        }
      } else if (dataset.id === 'ev-safety') {
        if (lowerQuery.includes('brake') || lowerQuery.includes('caliper')) {
          if (chunk.source.includes('Brakes')) matchCount += 3;
        }
      }

      const score = matchCount / (words.length || 1);
      return { chunk, score };
    }).sort((a, b) => b.score - a.score);

    const match = scoredChunks[0];
    const retrieved = match && match.score > 0.05 ? [match.chunk] : [dataset.chunks[0]];

    if (mode === 'standard') {
      let answer = "";
      if (dataset.id === 'health-benefits') {
        answer = "Standard RAG response states that mental health sessions are general reimbursed at 80% up to $1,000 per fiscal year. Standard claims must be submitted within 60 days of the session. Checks out smoothly.";
      } else if (dataset.id === 'quantum-vc') {
        answer = "Standard RAG states our superconducting transmon qubits operate at typical Josephson energy ratio Ej/Ec limit around 50, yielding average coherence times (T2) of 120 microseconds under stable environments.";
      } else {
        answer = "Standard RAG states company vehicles are governed by a severe winter bulletin. Battery cell heating pre-heating occurs around -10°C (14°F) for protection against cell wear.";
      }

      return {
        pipelineType: 'standard',
        query,
        steps: [
          { id: '1', nodeId: 'query', title: 'Query Received', description: 'Acquired user query directly from chatbot channel.', status: 'completed', durationMs: 20 },
          { id: '2', nodeId: 'embed', title: 'Dense Embeddings', description: 'Mapped string query to vector float geometry indices.', status: 'completed', durationMs: 45 },
          { id: '3', nodeId: 'vector-db', title: 'Vector Index Pull', description: `Cosine search matched ${retrieved[0].source} (similarity score: ${Math.max(0.48, match?.score || 0).toFixed(2)}).`, status: 'completed', durationMs: 85 },
          { id: '4', nodeId: 'synthesize', title: 'Context Direct Synthesis', description: 'Wrote answer draft directly with retrieved context without grading.', status: 'completed', durationMs: 220 },
          { id: '5', nodeId: 'response', title: 'Direct Post', description: 'Pushed output message to conversation screen.', status: 'completed', durationMs: 15 }
        ],
        retrievedChunks: retrieved,
        finalAnswer: answer,
        citations: retrieved.map(r => r.source),
        executionTimeMs: 385,
        costEstimateCents: 0.015
      };
    } else {
      // Agentic self-correcting RAG simulation
      const allRetrieved = scoredChunks.filter(sc => sc.score > 0.05).map(sc => sc.chunk);
      if (allRetrieved.length === 0) {
        allRetrieved.push(dataset.chunks[0], dataset.chunks[1] || dataset.chunks[0]);
      }

      let answer = "";
      if (dataset.id === 'health-benefits') {
        answer = `**Agentic Audit Analysis (Status: Verified Restricted):**\n\nNo, specified cognitive/neuro-divergent specialized assessments under **Rider 12B** are **NOT** eligible for full 100% reimbursement in August.\n\n**Key Findings:**\n- Rider 12B grants 100% (max $3,000) coverage **only if** pre-approval was submitted and logged prior to **June 30th**.\n- Since your planned session is in August, it fails the June 30th date criteria. It drops down and is processed under standard therapy rules (**HR-Policy-Sec-4.pdf**), meaning standard **80% reimbursement up to a max of $1,000** will apply.`;
      } else if (dataset.id === 'quantum-vc') {
        answer = `**Agentic Analytical Audit (Status: Multi-Device Profile):**\n\nComparing coherence profiles across designs:\n\n1. **Standard Superconducting Transmons:** Demonstrated average T2 coherence is **120 microseconds** operating under nominal conditions.\n2. **Flux-9 Prototype Circuit (Heavy Fluxonium):** Delivers coherence times exceeding **1,400 microseconds (1.4 ms)**.\n\n**Performance Impact:** This is an **11.6x enhancement** in quantum coherence. However, you must operate within a strict tuned configuration of **0.49 - 0.51 flux quanta** to prevent charge noise. Commercial hardware plans to migrate by Q4 2026.`;
      } else {
        answer = `**Agentic Safety Bulletin Assessment (Status: Critical Hazard Advisory):**\n\nYes, an emergency safety bulletin details a brake pressure delay under icy elements below -15°C.\n\n**Technical Details:**\n- Slush-clearing road salts can crust inside the micro-actuator seals on the secondary hydraulic calipers.\n- This incurs a delayed braking pressure response timing of up to **450 milliseconds lag**.\n- **Action Required:** Apply customized silicon dust-jackets inline with technical recall directive **SEC-BRAKE-09**. Dual-motor electric traction software is unaffected.`;
      }

      return {
        pipelineType: 'agentic',
        query,
        steps: [
          { id: '1', nodeId: 'query', title: 'Query Received', description: 'Acquired user query. Analyzed intent indices.', status: 'completed', durationMs: 20 },
          { id: '2', nodeId: 'router', title: 'Multi-Agent Routing', description: 'Classified question as constraint analysis. Dispatched specialized policy lookup.', status: 'completed', durationMs: 80 },
          { id: '3', nodeId: 'query-refinement', title: 'Search Parameter Tuning', description: 'Refined keyword terms to capture exception dates and threshold limits simultaneously.', status: 'completed', durationMs: 70 },
          { id: '4', nodeId: 'vector-db', title: 'Parallel Data Retreival', description: `Pulled matching documents: ${allRetrieved.map(r => r.source).join(', ')}.`, status: 'completed', durationMs: 110 },
          { id: '5', nodeId: 'doc-evaluator', title: 'Relevance Grading Agent', description: `Checked chunks relevance. Marked Rider / Safety exemptions as HIGHLY SIGNIFICANT.`, status: 'completed', durationMs: 95 },
          { id: '6', nodeId: 'synthesize', title: 'Multi-Perspective Synthesis', description: 'Assembled verified response combining threshold criteria and secondary policies.', status: 'completed', durationMs: 310 },
          { id: '7', nodeId: 'hallucination-grader', title: 'Grounding Verification Check', description: 'Audited answer statements against original text bytes. Veracity index: 100/100.', status: 'completed', durationMs: 105 },
          { id: '8', nodeId: 'response', title: 'Deliver Response', description: 'Formatted Markdown and delivered response context to conversational chat.', status: 'completed', durationMs: 15 }
        ],
        retrievedChunks: allRetrieved,
        finalAnswer: answer,
        citations: allRetrieved.map(r => r.source),
        executionTimeMs: 805,
        costEstimateCents: 0.104
      };
    }
  };

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    setInputText('');
    const userMessageId = `msg-${Date.now()}-user`;
    const botMessageId = `msg-${Date.now()}-bot`;

    // 1. Append user message
    setMessages(prev => [
      ...prev,
      {
        id: userMessageId,
        sender: 'user',
        text: trimmed
      }
    ]);

    setIsTyping(true);

    try {
      // 2. Query Back-end API endpoint
      const response = await fetch("/api/rag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datasetId: selectedDatasetId,
          query: trimmed,
          pipelineType: pipelineType
        })
      });

      if (!response.ok) throw new Error("Server error");
      
      const result: SimulationResult = await response.json();

      setIsTyping(false);
      setMessages(prev => [
        ...prev,
        {
          id: botMessageId,
          sender: 'agent',
          text: result.finalAnswer,
          pipelineType: result.pipelineType,
          executionTimeMs: result.executionTimeMs,
          costEstimateCents: result.costEstimateCents,
          steps: result.steps,
          citations: result.citations
        }
      ]);
    } catch (err) {
      console.warn("Back-end API offline or timeout. Resolving in-browser high fidelity fallback context.", err);
      
      // Simulate real-life short lag for organic chatbot feel
      setTimeout(() => {
        const fall = getOfflineSimulation(trimmed, pipelineType);
        setIsTyping(false);
        setMessages(prev => [
          ...prev,
          {
            id: botMessageId,
            sender: 'agent',
            text: fall.finalAnswer,
            pipelineType: fall.pipelineType,
            executionTimeMs: fall.executionTimeMs,
            costEstimateCents: fall.costEstimateCents,
            steps: fall.steps,
            citations: fall.citations
          }
        ]);
      }, 1000);
    }
  };

  const onSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  const getStepIcon = (nodeId: string) => {
    switch (nodeId) {
      case 'query': return <PlayCircle className="w-4 h-4 text-slate-400" />;
      case 'router': return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'query-refinement': return <Sparkles className="w-4 h-4 text-violet-400" />;
      case 'vector-db': return <Database className="w-4 h-4 text-blue-400" />;
      case 'doc-evaluator': return <ListFilter className="w-4 h-4 text-amber-500" />;
      case 'synthesize': return <Bot className="w-4 h-4 text-emerald-400" />;
      case 'hallucination-grader': return <CheckCircle2 className="w-4 h-4 text-teal-400" />;
      default: return <CornerDownRight className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-170px)]" id="chatbot-sandbox-container">
      
      {/* Configuration Sidebar */}
      <div className="lg:col-span-1 flex flex-col gap-5 bg-slate-900/20 border border-slate-800 rounded-2xl p-5" id="chat-sidebar">
        <div>
          <h3 className="text-xs font-bold font-mono text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            Current Knowledge Corpus
          </h3>
          <div className="space-y-2.5">
            {DATASETS.map((d) => {
              const isSelected = d.id === selectedDatasetId;
              return (
                <button
                  key={d.id}
                  onClick={() => onDatasetChange(d.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all text-xs cursor-pointer ${
                    isSelected 
                      ? 'bg-cyan-500/10 border-cyan-500/40 text-white font-semibold shadow-sm'
                      : 'bg-slate-950/40 border-slate-900 text-slate-400 hover:text-slate-350 hover:bg-slate-900/40'
                  }`}
                  id={`chat-corpus-${d.id}`}
                >
                  <div className="font-semibold text-slate-205 mb-0.5">{d.name}</div>
                  <div className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">{d.description}</div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="border-t border-slate-800/80 pt-4 mt-1">
          <h3 className="text-xs font-bold font-mono text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            RAG Strategy Toggle
          </h3>
          <div className="grid grid-cols-2 gap-2 bg-slate-950/80 p-1 border border-slate-850 rounded-xl">
            <button
              onClick={() => setPipelineType('standard')}
              className={`py-1.5 px-3 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                pipelineType === 'standard'
                  ? 'bg-slate-900 text-cyan-400 border border-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-400'
              }`}
              id="chat-toggle-std"
            >
              Standard Naive
            </button>
            <button
              onClick={() => setPipelineType('agentic')}
              className={`py-1.5 px-3 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                pipelineType === 'agentic'
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-sm shadow-cyan-950/20'
                  : 'text-slate-500 hover:text-slate-400'
              }`}
              id="chat-toggle-agentic"
            >
              Agentic Loop
            </button>
          </div>
          <p className="text-[10px] text-slate-500 mt-2.5 font-mono leading-relaxed uppercase">
            {pipelineType === 'agentic' 
              ? 'Multi-agent refinement, grading, validation, and correction loops active.'
              : 'Direct keyword match index extraction. Missing validation audits.'
            }
          </p>
        </div>

        <div className="border-t border-slate-800/80 pt-4 mt-auto">
          <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-850 text-[10px] font-mono space-y-1">
            <div className="text-slate-500">// ACTIVE ENDPOINT:</div>
            <div className="text-slate-300 font-bold truncate">POST /api/rag</div>
            <div className="text-slate-500 mt-2">// BACKEND MODEL:</div>
            <div className="text-emerald-400 font-bold">gemini-3.5-flash</div>
          </div>
        </div>
      </div>

      {/* Main Chat Sandbox Area */}
      <div className="lg:col-span-3 flex flex-col bg-slate-900/10 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative" id="chat-viewport">
        
        {/* Top bar status */}
        <div className="px-6 py-4 bg-slate-900/40 border-b border-slate-800 flex justify-between items-center" id="chat-top-header">
          <div className="flex items-center gap-2.5">
            <MessageSquare className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                Conversational Sandbox Chatbot
              </h3>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5 uppercase">
                RAG Strategy: {pipelineType === 'standard' ? 'Standard Naive Vector Search' : 'Agentic Corrective Loop'}
              </p>
            </div>
          </div>
          <button 
            onClick={() => setMessages([messages[0]])}
            className="p-1.5 px-3 bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-lg text-[10px] font-semibold text-slate-400 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            title="Clear conversation messages"
            id="chat-clear-btn"
          >
            <RefreshCw className="w-3 h-3" />
            Clear Chat
          </button>
        </div>

        {/* Message body container */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 select-text max-h-[calc(100vh-320px)]" id="chat-scroller">
          {messages.map((msg, index) => {
            const isAgent = msg.sender === 'agent';
            const hasTrace = msg.steps && msg.steps.length > 0;
            const isTraceExpanded = expandedTraceId === msg.id;

            return (
              <div 
                key={index} 
                className={`flex gap-4 max-w-[85%] ${isAgent ? 'mr-auto' : 'ml-auto flex-row-reverse'}`}
                id={`chat-msg-row-${index}`}
              >
                {/* Avatar Icon */}
                <div className={`w-8.5 h-8.5 rounded-xl border flex items-center justify-center shrink-0 ${
                  isAgent 
                    ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400 shadow-sm shadow-cyan-950/30' 
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`} id={`chat-avatar-${index}`}>
                  {isAgent ? <Bot className="w-4.5 h-4.5" /> : <User className="w-4.5 h-4.5" />}
                </div>

                {/* Bubble Container */}
                <div className="space-y-2 w-full">
                  <div className={`p-4 rounded-2xl relative border ${
                    isAgent 
                      ? 'bg-slate-900/60 border-slate-850 text-slate-200' 
                      : 'bg-cyan-950/15 border-cyan-800/20 text-slate-250 text-white'
                  }`} id={`chat-bubble-${index}`}>
                    
                    {/* Render message with line-by-line formatting */}
                    <div className="text-[12.5px] leading-relaxed font-sans whitespace-pre-line select-text font-light tracking-wide">
                      {msg.text}
                    </div>

                    {/* Metadata tags (latency / costs) */}
                    {isAgent && (msg.executionTimeMs || msg.costEstimateCents) ? (
                      <div className="flex items-center gap-3 border-t border-slate-805 border-slate-800/40 pt-2.5 mt-3 text-[9px] font-mono text-slate-500" id={`chat-meta-${index}`}>
                        <span>RAG MODE: <strong className="text-cyan-400 uppercase">{msg.pipelineType}</strong></span>
                        <span>•</span>
                        <span>LATENCY: <strong className="text-emerald-400">{msg.executionTimeMs}ms</strong></span>
                        <span>•</span>
                        <span>FEES: <strong className="text-cyan-400">{msg.costEstimateCents?.toFixed(3)}¢</strong></span>
                      </div>
                    ) : null}
                  </div>

                  {/* Inline collapse RAG timeline trace log */}
                  {isAgent && hasTrace && (
                    <div className="mr-auto w-full" id={`chat-trace-container-${index}`}>
                      <button 
                        onClick={() => setExpandedTraceId(isTraceExpanded ? null : msg.id)}
                        className={`text-[10px] font-mono px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${
                          isTraceExpanded 
                            ? 'bg-slate-900 text-cyan-400 border-cyan-950 shadow-sm' 
                            : 'bg-slate-950 text-slate-400 border-slate-900 hover:text-slate-200 hover:bg-slate-900/50'
                        }`}
                        id={`chat-trace-toggle-${index}`}
                      >
                        <Cpu className="w-3 h-3" />
                        {isTraceExpanded ? 'Hide Trace Timeline Logs ▲' : 'Inspect RAG Trace Nodes ▼'}
                      </button>

                      <AnimatePresence>
                        {isTraceExpanded && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden mt-1 bg-slate-950 border border-slate-900 rounded-xl p-3.5 space-y-2.5 text-[11px] max-w-full font-mono shadow-inner"
                            id={`chat-trace-panel-${index}`}
                          >
                            <div className="text-[9px] font-bold uppercase text-slate-500 border-b border-slate-900 pb-1.5 mb-2">
                              RAG Pipeline Decision Trace:
                            </div>
                            <div className="space-y-2 select-text" id={`trace-steps-stack-${index}`}>
                              {msg.steps?.map((step, idx) => (
                                <div key={step.id} className="flex gap-2.5 items-start text-slate-400" id={`trace-node-${step.id}`}>
                                  <div className="shrink-0 mt-0.5" id={`trace-node-icon-${step.id}`}>
                                    {getStepIcon(step.nodeId)}
                                  </div>
                                  <div className="flex-1">
                                    <div className="flex justify-between text-slate-300 font-semibold text-[10.5px]">
                                      <span>{step.title}</span>
                                      <span className="text-slate-500 text-[9px]">{step.durationMs}ms</span>
                                    </div>
                                    <p className="text-[10px] text-slate-500 leading-normal mt-0.5">{step.description}</p>
                                  </div>
                                </div>
                              ))}
                            </div>

                            {msg.citations && msg.citations.length > 0 && (
                              <div className="border-t border-slate-900 pt-2.5 mt-2 flex gap-1.5 flex-wrap items-center">
                                <span className="text-[9px] text-slate-600 font-bold uppercase uppercase">SOURCES:</span>
                                {msg.citations.map((cite, i) => (
                                  <span key={i} className="text-[9px] bg-slate-900/80 border border-slate-800 text-slate-400 rounded px-1.5 p-0.5 font-mono">
                                    {cite}
                                  </span>
                                ))}
                              </div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )}

                </div>
              </div>
            );
          })}

          {/* Typing indicator */}
          {isTyping && (
            <div className="flex gap-4 max-w-[85%] mr-auto" id="chat-typing-indicator">
              <div className="w-8.5 h-8.5 rounded-xl border border-cyan-500/10 bg-cyan-500/5 text-cyan-400 flex items-center justify-center shrink-0">
                <Bot className="w-4.5 h-4.5 animate-pulse" />
              </div>
              <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-850 flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="inline-block w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="inline-block w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          {/* Dummy element for scroll anchoring */}
          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Starter Prompts */}
        <div className="px-6 py-2.5 bg-slate-950/40 border-t border-slate-850 flex flex-wrap gap-2 overflow-x-auto select-none shrink-0" id="chat-quickstarters">
          <span className="text-[9px] font-mono text-slate-500 uppercase self-center mr-1">Suggestions:</span>
          {getSuggestions().map((sug, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(sug.text)}
              className="text-[10px] font-medium bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-slate-400 hover:text-cyan-400 p-1 px-2.5 rounded-lg transition-all cursor-pointer select-none active:scale-95 truncate max-w-xs"
              id={`quick-sug-${i}`}
              title={sug.text}
            >
              {sug.label}
            </button>
          ))}
        </div>

        {/* Form Chat Prompt Input Container */}
        <form onSubmit={onSubmitForm} className="p-4 bg-slate-900/40 border-t border-slate-800 flex gap-3 items-center shrink-0" id="chat-form">
          <input 
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Ask a question regarding ${activeDataset.name}...`}
            className="flex-1 bg-slate-950/80 hover:bg-slate-950 focus:bg-slate-950 p-3 px-4.5 rounded-xl border border-slate-800 focus:border-cyan-500/40 text-xs font-sans text-white placeholder:text-slate-600 focus:ring-1 focus:ring-cyan-500/25 transition-all outline-none"
            id="chat-input-text"
            disabled={isTyping}
          />
          <button
            type="submit"
            disabled={isTyping || !inputText.trim()}
            className="p-3 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded-xl transition hover:bg-cyan-500/20 active:scale-95 disabled:opacity-40 disabled:hover:bg-cyan-500/10 disabled:scale-100 cursor-pointer flex items-center justify-center shrink-0"
            id="chat-send-btn"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>

    </div>
  );
}

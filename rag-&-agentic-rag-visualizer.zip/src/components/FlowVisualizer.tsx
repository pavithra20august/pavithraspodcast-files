import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, Binary, Database, Cpu, CheckCircle2, 
  GitFork, RefreshCw, Eye, ShieldAlert, Sparkles, HelpCircle
} from 'lucide-react';
import { GraphNode, GraphEdge, RAGStep } from '../types';

interface FlowVisualizerProps {
  pipelineType: 'standard' | 'agentic';
  activeNodeId: string | null;
  steps: RAGStep[];
  currentStepIndex: number;
}

export const FlowVisualizer: React.FC<FlowVisualizerProps> = ({
  pipelineType,
  activeNodeId,
  steps,
  currentStepIndex
}) => {
  const [selectedNodeInfo, setSelectedNodeInfo] = useState<GraphNode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Define Standard RAG Nodes
  const standardNodes: GraphNode[] = [
    { id: 'query', label: 'User Query', role: 'Main Entry Point', x: 10, y: 50, type: 'input', description: 'The raw, unfiltered natural language query entered by the user.' },
    { id: 'embed', label: 'Vector Embedder', role: 'Embedding Service', x: 30, y: 50, type: 'process', description: 'Translates textual words into dense numerical vectors (usually 1536 dimensions) for spatial match calculation.' },
    { id: 'vector-db', label: 'Vector Index', role: 'Knowledge Base', x: 50, y: 50, type: 'database', description: 'Computes cosine similarity against document indexes relative to the query string vectors.' },
    { id: 'synthesize', label: 'LLM Synthesizer', role: 'Context Assimilation', x: 70, y: 50, type: 'process', description: 'Takes original query and appends standard retrieved hits directly to prompt context window.' },
    { id: 'response', label: 'Final Output', role: 'Standard Answer', x: 90, y: 50, type: 'output', description: 'Delivers generated text directly. Contains no post-check filters or accuracy loops.' }
  ];

  // Define Standard RAG Edges
  const standardEdges: GraphEdge[] = [
    { from: 'query', to: 'embed' },
    { from: 'embed', to: 'vector-db' },
    { from: 'vector-db', to: 'synthesize' },
    { from: 'synthesize', to: 'response' }
  ];

  // Define Agentic RAG Nodes with specialized self-correction pathways
  const agenticNodes: GraphNode[] = [
    { id: 'query', label: 'Input Query', role: 'Main Entry Point', x: 8, y: 50, type: 'input', description: 'Accepts the raw multi-part query requiring quantitative parsing or policy overrides.' },
    { id: 'router', label: 'Router Agent', role: 'Intent Classifier', x: 24, y: 50, type: 'agent', description: 'Determines which knowledge indexes, APIs, or specialized tools are best matching the query intent.' },
    { id: 'query-refinement', label: 'Query Optimizer', role: 'Search Formulation Agent', x: 42, y: 25, type: 'agent', description: 'Rewrites user keywords into rich, semantic strings or multi-phrase query vectors.' },
    { id: 'vector-db', label: 'Vector Database', role: 'Parallel Retrievers', x: 60, y: 25, type: 'database', description: 'Retrieves relevant document segments using specialized multi-part search query targets.' },
    { id: 'doc-evaluator', label: 'Relevance Grader', role: 'Evaluation Agent', x: 60, y: 75, type: 'agent', description: 'Checks if retrieved chunks are genuinely relevant to the query. If score is low, triggers query re-generation loops!' },
    { id: 'synthesize', label: 'Synthesizer', role: 'LLM Generator', x: 76, y: 50, type: 'process', description: 'Compiles the fully verified relevant chunks and coordinates comparative generation templates.' },
    { id: 'hallucination-grader', label: 'Grounding Agent', role: 'Fact Checker', x: 88, y: 22, type: 'agent', description: 'Compares generator output sentences against retrieved source material. Rejects hallucinated statements.' },
    { id: 'response', label: 'Verified Output', role: 'Production Guardrail', x: 92, y: 50, type: 'output', description: 'The finalized bulletproof answer after multiple relevance filters and grounding tests pass successfully.' }
  ];

  // Agentic Edges (with loops!)
  const agenticEdges: GraphEdge[] = [
    { from: 'query', to: 'router' },
    { from: 'router', to: 'query-refinement' },
    { from: 'query-refinement', to: 'vector-db' },
    { from: 'vector-db', to: 'doc-evaluator' },
    // Feed back loop if doc relevance is low or fails
    { from: 'doc-evaluator', to: 'query-refinement', label: 'Re-Write Loop (on irrelevant chunks)', animated: true },
    { from: 'doc-evaluator', to: 'synthesize', label: 'Approved context' },
    { from: 'synthesize', to: 'hallucination-grader' },
    // Hallucination corrective loop
    { from: 'hallucination-grader', to: 'synthesize', label: 'Re-align synthesis' },
    { from: 'hallucination-grader', to: 'response', label: 'Passed grounding check' }
  ];

  const nodes = pipelineType === 'standard' ? standardNodes : agenticNodes;
  const edges = pipelineType === 'standard' ? standardEdges : agenticEdges;

  // Active step info helper
  const activeStep = steps[currentStepIndex];

  // Select icon for nodes based on their identifier
  const getNodeIcon = (id: string) => {
    switch(id) {
      case 'query': return <MessageSquare className="w-5 h-5 text-sky-400" id={`icon-${id}`} />;
      case 'embed': return <Binary className="w-5 h-5 text-indigo-400" id={`icon-${id}`} />;
      case 'vector-db': return <Database className="w-5 h-5 text-emerald-400" id={`icon-${id}`} />;
      case 'router': return <GitFork className="w-5 h-5 text-violet-400" id={`icon-${id}`} />;
      case 'query-refinement': return <Sparkles className="w-5 h-5 text-amber-400" id={`icon-${id}`} />;
      case 'doc-evaluator': return <ShieldAlert className="w-5 h-5 text-red-400" id={`icon-${id}`} />;
      case 'synthesize': return <Cpu className="w-5 h-5 text-purple-400" id={`icon-${id}`} />;
      case 'hallucination-grader': return <Eye className="w-5 h-5 text-teal-400" id={`icon-${id}`} />;
      case 'response': return <CheckCircle2 className="w-5 h-5 text-pink-400" id={`icon-${id}`} />;
      default: return <HelpCircle className="w-5 h-5 text-slate-400" id={`icon-${id}`} />;
    }
  };

  // Check state of step
  const getNodeState = (nodeId: string) => {
    if (activeNodeId === nodeId) return 'active';
    
    // Check if node has been completed in previous steps of the simulation
    const stepsUpToNow = steps.slice(0, currentStepIndex + 1);
    const completedStep = stepsUpToNow.find(s => s.nodeId === nodeId);
    if (completedStep) {
      if (completedStep.status === 'warning') return 'warning';
      if (completedStep.status === 'failed') return 'failed';
      return 'completed';
    }
    return 'pending';
  };

  useEffect(() => {
    // Sync selected node with currently active node
    if (activeNodeId) {
      const liveNode = nodes.find(n => n.id === activeNodeId);
      if (liveNode) setSelectedNodeInfo(liveNode);
    }
  }, [activeNodeId, pipelineType]);

  const drawBezierCurve = (x1: number, y1: number, x2: number, y2: number) => {
    const dx = Math.abs(x2 - x1);
    const cp1x = x1 + dx * 0.4;
    const cp1y = y1;
    const cp2x = x2 - dx * 0.4;
    const cp2y = y2;
    return `M ${x1} ${y1} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${x2} ${y2}`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/10 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl relative" id="flow-visualizer-container">
      {/* Top Bar Status */}
      <div className="px-6 py-4 bg-slate-900/40 border-b border-slate-800 flex justify-between items-center z-10" id="flow-top-bar">
        <div>
          <h3 className="text-xs font-bold tracking-wider text-slate-200 font-mono uppercase" id="pipeline-title">
            INTERACTIVE DIAGRAM: {pipelineType === 'standard' ? 'STANDARD DIRECT PIPELINE' : 'AGENTIC CORRECTION NETWORKS'}
          </h3>
          <p className="text-[10px] text-slate-500 font-mono mt-0.5 uppercase" id="pipeline-meta">
            {pipelineType === 'standard' ? 'Linear Keyword Database Search' : 'Adaptive Self-Correction Control Loop'}
          </p>
        </div>
        <div className="flex items-center gap-2.5" id="active-state-indicators">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
          </span>
          <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase tracking-wider" id="pipeline-mode-badge">
            SIMULATOR ACTIVE
          </span>
        </div>
      </div>

      {/* Node Canvas Layout */}
      <div className="flex-1 relative min-h-[350px] lg:min-h-[400px] overflow-hidden" ref={containerRef} id="canvas-view-pane">
        {/* Connection Vector Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" id="flow-vector-svg">
          <defs>
            <linearGradient id="activeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.85"/>
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.85"/>
            </linearGradient>
            <linearGradient id="inactiveGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#334155" stopOpacity="0.25"/>
              <stop offset="100%" stopColor="#334155" stopOpacity="0.25"/>
            </linearGradient>
            <linearGradient id="loopGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#d97706" stopOpacity="0.8"/>
            </linearGradient>
          </defs>

          {/* Draw connection pathways */}
          {edges.map((edge, i) => {
            const fromNode = nodes.find(n => n.id === edge.from);
            const toNode = nodes.find(n => n.id === edge.to);
            if (!fromNode || !toNode) return null;

            const x1 = fromNode.x;
            const y1 = fromNode.y;
            const x2 = toNode.x;
            const y2 = toNode.y;

            const fromState = getNodeState(edge.from);
            const toState = getNodeState(edge.to);
            const isPathActive = (fromState === 'completed' || fromState === 'active') && 
                               (toState === 'completed' || toState === 'active');
            
            // Highlight specific self-grading correction loops in red/orange gradient
            const isLoop = edge.from === 'doc-evaluator' && edge.to === 'query-refinement' ||
                           edge.from === 'hallucination-grader' && edge.to === 'synthesize';

            let dPath = "";
            if (isLoop) {
              // Custom looping path curves to look clean and separate
              if (edge.from === 'doc-evaluator') {
                dPath = `M ${x1}% ${y1}% Q 45% 90%, ${x2}% ${y2}%`;
              } else {
                dPath = `M ${x1}% ${y1}% Q 82% 5%, ${x2}% ${y2}%`;
              }
            } else {
              dPath = drawBezierCurve(x1, y1, x2, y2);
              // Ensure coordinates are percentages
              dPath = dPath.replace(/([0-9.]+)/g, '$1%');
            }

            return (
              <g key={`edge-${edge.from}-${edge.to}-${i}`} id={`edge-group-${edge.from}-${edge.to}`}>
                {/* Background shadow curve path */}
                <path
                  d={dPath}
                  fill="none"
                  stroke="#020617"
                  strokeWidth="6"
                  className="transition-all duration-300"
                />
                
                {/* Visual line */}
                <path
                  d={dPath}
                  fill="none"
                  stroke={isLoop ? "url(#loopGrad)" : isPathActive ? "url(#activeGrad)" : "url(#inactiveGrad)"}
                  strokeWidth={isPathActive ? "2.5" : "1.5"}
                  strokeDasharray={isLoop || (edge.from === 'doc-evaluator' && activeStep?.nodeId === 'doc-evaluator' && activeStep?.status === 'warning') ? "5, 5" : "0"}
                  className={`transition-all duration-300 ${isPathActive ? 'shadow-glow' : ''} ${isLoop ? 'animate-[dash_20s_linear_infinite]' : ''}`}
                />

                {/* Animated token packets flying through active paths */}
                {isPathActive && !isLoop && (
                  <circle r="4.5" fill="#22d3ee" className="filter drop-shadow-[0_0_8px_#22d3ee]" id={`packet-${edge.from}-${edge.to}`}>
                    <animateMotion 
                      path={dPath.replace(/%/g, '')} 
                      dur="2.5s" 
                      repeatCount="indefinite" 
                    />
                  </circle>
                )}
                
                {isLoop && activeStep?.nodeId === edge.from && activeStep?.status === 'warning' && (
                  <circle r="5" fill="#ef4444" className="filter drop-shadow-[0_0_10px_#f87171]" id={`loop-packet-${edge.from}-${edge.to}`}>
                    <animateMotion
                      path={dPath.replace(/%/g, '')}
                      dur="1.5s"
                      repeatCount="indefinite"
                    />
                  </circle>
                )}
              </g>
            );
          })}
        </svg>

        {/* CSS animation hack inside inline style */}
        <style dangerouslySetInnerHTML={{__html: `
          @keyframes dash {
            to {
              stroke-dashoffset: -100px;
            }
          }
          .shadow-glow {
            filter: drop-shadow(0px 0px 4px rgba(56, 189, 248, 0.4));
          }
        `}} />

        {/* Nodes overlay layer */}
        {nodes.map((node) => {
          const state = getNodeState(node.id);
          const isActive = activeNodeId === node.id;
          const isSelected = selectedNodeInfo?.id === node.id;

          // Color themes based on state
          let borderStyle = 'border-slate-800 bg-slate-900/40 text-slate-500';
          let glowStyle = '';
          if (state === 'active') {
            borderStyle = 'border-cyan-400 bg-slate-900/90 text-slate-100 ring-2 ring-cyan-950 scale-105';
            glowStyle = 'shadow-[0_0_20px_rgba(34,211,238,0.25)]';
          } else if (state === 'completed') {
            borderStyle = 'border-emerald-500/80 bg-slate-900/60 text-slate-200';
            glowStyle = 'shadow-[0_0_10px_rgba(16,185,129,0.1)]';
          } else if (state === 'warning') {
            borderStyle = 'border-amber-500 bg-slate-950 text-slate-200 ring-2 ring-amber-500/10';
            glowStyle = 'shadow-[0_0_15px_rgba(245,158,11,0.2)]';
          } else if (state === 'failed') {
            borderStyle = 'border-rose-500 bg-slate-950 text-slate-200 ring-2 ring-rose-500/10';
            glowStyle = 'shadow-[0_0_15px_rgba(244,63,94,0.2)]';
          }

          if (isSelected && state !== 'active') {
            borderStyle += ' border-dashed border-cyan-500 bg-slate-900/70';
          }

          return (
            <div
              key={node.id}
              id={`node-${node.id}`}
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20 select-none transition-all duration-300 hover:scale-105 ${borderStyle} ${glowStyle} flex flex-col items-center w-28 sm:w-32 p-2 sm:p-3 rounded-xl border text-center`}
              onClick={() => setSelectedNodeInfo(node)}
            >
              {/* Highlight Ring around currently active node */}
              <AnimatePresence>
                {isActive && (
                  <motion.div 
                    layoutId="activeHighlight"
                    className="absolute -inset-1 rounded-2xl border border-cyan-400 pointer-events-none"
                    transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                    id={`active-ring-${node.id}`}
                  />
                )}
              </AnimatePresence>

              {/* Icon Container */}
              <div className={`p-2 rounded-lg mb-1.5 transition-colors ${state === 'active' ? 'bg-cyan-550/10' : state === 'completed' ? 'bg-emerald-555/10' : 'bg-slate-950/40'}`} id={`icon-wrap-${node.id}`}>
                {getNodeIcon(node.id)}
              </div>

              {/* Node Title & Detail */}
              <h4 className="text-xs font-semibold font-sans tracking-tight leading-tight truncate w-full" id={`node-label-${node.id}`}>
                {node.label}
              </h4>
              <span className="text-[9px] font-mono opacity-65 font-medium tracking-tight truncate w-full block mt-0.5" id={`node-role-${node.id}`}>
                {node.role}
              </span>

              {/* Completion status circles */}
              <div className="absolute top-1.5 right-1.5 flex gap-1" id={`status-indicators-${node.id}`}>
                {state === 'completed' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                {state === 'warning' && <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />}
                {state === 'active' && <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Node Inspector / Explanatory Board */}
      <div className="bg-slate-900/40 border-t border-slate-800 p-5 mt-auto z-10" id="flow-inspector-panel">
        <AnimatePresence mode="wait">
          {selectedNodeInfo ? (
            <motion.div
              key={selectedNodeInfo.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center"
              id="inspector-details"
            >
              <div className="flex-1" id="inspector-content">
                <div className="flex items-center gap-2" id="inspector-header">
                  <div className="p-1 px-2.5 rounded bg-slate-950 border border-slate-805 text-[10px] font-mono text-cyan-400 uppercase font-bold" id="node-type-badge font-bold">
                    {selectedNodeInfo.type}
                  </div>
                  <h4 className="font-semibold text-xs tracking-wide text-slate-100 font-sans" id="selected-node-title">
                    {selectedNodeInfo.label} — <span className="text-slate-400 font-normal font-mono text-[10px]">{selectedNodeInfo.role}</span>
                  </h4>
                </div>
                <p className="text-[11px] text-slate-400 mt-2 leading-relaxed" id="selected-node-text">
                  {selectedNodeInfo.description}
                </p>
              </div>

              {/* Context specifics based on active run */}
              <div className="w-full md:w-auto shrink-0 flex flex-col gap-1.5 bg-slate-950/60 rounded-xl p-3 border border-slate-800" id="inspector-metrics">
                <span className="text-[9px] font-mono text-slate-500 font-bold uppercase" id="current-status-lbl">CURRENT RUN STATUS:</span>
                <span className={`text-[10px] font-mono font-bold flex items-center gap-1.5 uppercase`} id="node-run-status-badge">
                  {getNodeState(selectedNodeInfo.id) === 'active' && (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                      <span className="text-cyan-400">Processing Node...</span>
                    </>
                  )}
                  {getNodeState(selectedNodeInfo.id) === 'completed' && <span className="text-emerald-400">✔ Completed Approved</span>}
                  {getNodeState(selectedNodeInfo.id) === 'warning' && <span className="text-amber-400">⚠ Corrective Loop Rewrite</span>}
                  {getNodeState(selectedNodeInfo.id) === 'failed' && <span className="text-rose-400">✘ Critical Alert Halt</span>}
                  {getNodeState(selectedNodeInfo.id) === 'pending' && <span className="text-slate-650 text-slate-600">◌ Queue (Standby)</span>}
                </span>

                {/* Additional details if it matches active step */}
                {activeStep && activeStep.nodeId === selectedNodeInfo.id && activeStep.outputDetails && (
                  <div className="text-[9px] text-slate-400 font-mono mt-1 border-t border-slate-900 pt-1 w-full max-w-[280px] break-words line-clamp-2" title={activeStep.outputDetails} id="step-output-details">
                    Log: {activeStep.outputDetails}
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="text-slate-500 text-xs text-center font-sans py-2" id="inspector-no-selection">
              💡 Hover or click on any visual node above to inspect its architectural specifications and active state logs.
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

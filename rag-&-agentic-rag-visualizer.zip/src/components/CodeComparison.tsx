import React, { useState } from 'react';
import { Terminal, FileCode, Check, Copy } from 'lucide-react';

interface CodeComparisonProps {}

export const CodeComparison: React.FC<CodeComparisonProps> = () => {
  const [activeTab, setActiveTab] = useState<'python' | 'typescript'>('python');
  const [copying, setCopying] = useState<string | null>(null);

  const pythonStandard = `import openai
from pinecone import Pinecone

# 1. Take User Input & Embed It
pc = Pinecone(api_key="your_key")
index = pc.Index("aura-company-index")
query = "Can I get cognitive test therapy in August?"
query_vector = openai.embeddings.create(
    input=query, model="text-embedding-3-small"
).data[0].embedding

# 2. Naive Similarity Search (Top-1)
retrieved_match = index.query(
    vector=query_vector, 
    top_k=1, 
    include_metadata=True
)
context = retrieved_match["matches"][0]["metadata"]["content"]

# 3. Naive Vector Augmented Synthesis
prompt = f"Using this context: {context}.\\nAnswer: {query}"
response = openai.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": prompt}]
)
print("Response:", response.choices[0].message.content)
# ⚠ ISSUE: Fails if exceptions require deep multi-phrase searching!`;

  const pythonAgentic = `from typing import List, Dict, Literal
from langgraph.graph import StateGraph, START, END

# Define Agent State
class AgentState(Dict):
    query: str
    sub_queries: List[str]
    retrieved_docs: List[Dict]
    is_relevant: bool
    answer: str
    grounded: bool

# 1. Router Agent Node
def router_node(state: AgentState):
    # Specialized classifier categorizes intent
    intent = call_routing_llm(state["query"])
    return {"route": intent}

# 2. Query Refinement Agent Node
def query_refinement_node(state: AgentState):
    refined = generate_search_terms(state["query"])
    return {"sub_queries": refined}

# 3. Parallel Search Node
def multi_search_node(state: AgentState):
    all_chunks = []
    for q in state["sub_queries"]:
        all_chunks.extend(vector_db.search(q))
    return {"retrieved_docs": all_chunks}

# 4. Relevance Evaluator Agent Node (Double-check)
def relevance_grader_node(state: AgentState):
    score = score_documents_relevance(state["query"], state["retrieved_docs"])
    if score < 0.7:
        # Trigger correction rewriting loop!
        return {"is_relevant": False}
    return {"is_relevant": True}

# 5. Hallucination Grader Agent Node (Grounding verification)
def hallucination_grader_node(state: AgentState):
    fidelity = check_answer_against_facts(state["answer"], state["retrieved_docs"])
    return {"grounded": fidelity}

# Define Adaptive Flow Topology
workflow = StateGraph(AgentState)
workflow.add_node("router", router_node)
workflow.add_node("optimizer", query_refinement_node)
workflow.add_node("vector_db", multi_search_node)
workflow.add_node("grader", relevance_grader_node)
workflow.add_node("synthesize", synthesis_node)
workflow.add_node("fact_check", hallucination_grader_node)

# Adaptive Connection Rules
workflow.add_conditional_edges(
    "grader",
    lambda state: "optimizer" if not state["is_relevant"] else "synthesize"
)
workflow.add_conditional_edges(
    "fact_check",
    lambda state: "synthesize" if not state["grounded"] else END
)

app = workflow.compile()`;

  const tsStandard = `import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Naive Standard RAG Process
async function standardRAG(userQuery: string) {
  // 1. Keyword vectors or simple pull
  const match = await localRetriever.findTopMatch(userQuery);
  
  // 2. Direct feed context
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: \`Context: \${match.content}\\nQuestion: \${userQuery}\`
  });
  
  return response.text;
}`;

  const tsAgentic = `import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Multi-Agent Correction Walkthrough
async function agenticRAGStateMachine(query: string) {
  // Step 1: Query Routing Agent
  const routeDecision = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: \`Route this query to policy, physics, or safety index: "\${query}"\`,
    config: { responseMimeType: "application/json" }
  });
  
  // Step 2: Query Rewriting Agent
  const refinedSearch = await rewriteQuery(query, routeDecision);
  
  let docs = await db.search(refinedSearch);
  
  // Step 3: Self-Correction Relevance Grading Loop
  let attempts = 0;
  while (attempts < 3) {
    const gradeResult = await scoreDocs(query, docs);
    if (gradeResult.isRelevant) break;
    
    // Rewrite query and search again!
    const fallbackSearch = await queryOptimizer(query, docs);
    docs = await db.search(fallbackSearch);
    attempts++;
  }
  
  // Step 4: Synthesize & Hallucination test
  const answer = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: \`Draft answer based ONLY on: \${JSON.stringify(docs)}\`
  });
  
  return answer.text;
}`;

  const handleCopy = (code: string, label: string) => {
    navigator.clipboard.writeText(code);
    setCopying(label);
    setTimeout(() => setCopying(null), 2000);
  };

  const codeBlocks = activeTab === 'python' 
    ? { std: pythonStandard, agentic: pythonAgentic, lang: 'python' }
    : { std: tsStandard, agentic: tsAgentic, lang: 'typescript' };

  return (
    <div className="flex flex-col h-full bg-slate-900/10 border border-slate-800 rounded-2xl overflow-hidden shadow-xl" id="code-comparison-wrapper">
      {/* Tab Switcher */}
      <div className="px-6 py-4 bg-slate-900/40 border-b border-slate-800 flex justify-between items-center" id="code-comparison-header">
        <div className="flex items-center gap-2.5" id="code-title-wrapper">
          <Terminal className="w-5 h-5 text-cyan-400" id="code-terminal-icon" />
          <h3 className="text-xs font-bold text-slate-200 font-mono tracking-wider" id="code-title">
            UNDER THE HOOD: ARCHITECTURE COMPARISON
          </h3>
        </div>
        <div className="flex items-center gap-2 bg-slate-950/80 p-0.5 rounded-lg border border-slate-800" id="lang-selectors">
          <button 
            id="lang-python-btn"
            onClick={() => setActiveTab('python')}
            className={`px-3 py-1 text-[11px] font-mono font-bold rounded transition-all cursor-pointer ${
              activeTab === 'python' 
                ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shadow-sm' 
                : 'text-slate-500 hover:text-slate-300 border border-transparent'
            }`}
          >
            Python (LangGraph)
          </button>
          <button 
            id="lang-ts-btn"
            onClick={() => setActiveTab('typescript')}
            className={`px-3 py-1 text-[11px] font-mono font-bold rounded transition-all cursor-pointer ${
              activeTab === 'typescript' 
                ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shadow-sm' 
                : 'text-slate-500 hover:text-slate-300 border border-transparent'
            }`}
          >
            TypeScript SDK
          </button>
        </div>
      </div>

      {/* Code Blocks side-by-side */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-2 divide-y xl:divide-y-0 xl:divide-x divide-slate-900 overflow-y-auto max-h-[500px]" id="pane-container">
        
        {/* Naive Standard RAG Column */}
        <div className="flex flex-col h-full" id="std-code-col">
          <div className="px-5 py-3.5 bg-slate-900/20 border-b border-slate-900/40 flex justify-between items-center" id="std-code-header">
            <div className="flex items-center gap-2" id="std-code-title">
              <FileCode className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-mono text-slate-400 font-bold">Standard Naive RAG Protocol</span>
            </div>
            <button 
              id="copy-std-btn"
              onClick={() => handleCopy(codeBlocks.std, 'std')}
              className="text-[10px] font-mono text-slate-500 hover:text-slate-300 flex items-center gap-1 p-1 px-2 hover:bg-slate-900 rounded border border-transparent hover:border-slate-800 transition"
            >
              {copying === 'std' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
          <pre className="flex-1 p-5 text-xs font-mono text-slate-400 overflow-x-auto select-text leading-relaxed bg-[#020617]" id="std-code-snippet">
            <code>{codeBlocks.std}</code>
          </pre>
        </div>

        {/* Self-Corrective Agentic RAG List Column */}
        <div className="flex flex-col h-full" id="agentic-code-col">
          <div className="px-5 py-3.5 bg-slate-900/20 border-b border-slate-900/40 flex justify-between items-center" id="agentic-code-header">
            <div className="flex items-center gap-2" id="agentic-code-title">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-mono text-cyan-400 font-bold">Agentic Corrective Loop Model</span>
            </div>
            <button 
              id="copy-agentic-btn"
              onClick={() => handleCopy(codeBlocks.agentic, 'agentic')}
              className="text-[10px] font-mono text-slate-500 hover:text-slate-300 flex items-center gap-1 p-1 px-2 hover:bg-slate-900 rounded border border-transparent hover:border-slate-800 transition"
            >
              {copying === 'agentic' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 font-medium font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
          <pre className="flex-1 p-5 text-xs font-mono text-cyan-300/80 overflow-x-auto select-text leading-relaxed bg-slate-950" id="agentic-code-snippet">
            <code>{codeBlocks.agentic}</code>
          </pre>
        </div>
      </div>

      {/* Code Summary Explanation Panel */}
      <div className="p-4 bg-slate-905 border-t border-slate-800 text-slate-400 text-xs font-sans leading-relaxed" id="code-summary-narrative">
        🔑 <strong className="text-slate-200">The Core Contrast:</strong> While Standard RAG relies completely on a single 
        one-shot semantic search containing direct text overlaps, Agentic RAG structures the process as an 
        <strong className="text-cyan-400"> adaptive state graph</strong>. The Agents dynamically grade relevance, rewrite 
        dissimilar search queries, cross-check numeric statements, and self-correct prior to pushing context to synthetic production gates.
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { BookOpen, AlertOctagon, RefreshCw, Layers, ShieldCheck, LucideIcon } from 'lucide-react';

interface Concept {
  id: string;
  title: string;
  subtitle: string;
  icon: LucideIcon;
  badge: string;
  badgeColor: string;
  content: React.ReactNode;
}

export const InfoPanel: React.FC = () => {
  const [activeConcept, setActiveConcept] = useState<string>('what-is-rag');

  const concepts: Concept[] = [
    {
      id: 'what-is-rag',
      title: 'What is Naive RAG?',
      subtitle: 'The Baseline Architecture of Search-Augmentation',
      icon: BookOpen,
      badge: 'Level 1: Static',
      badgeColor: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
      content: (
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans" id="con-rag-desc">
          <p>
            <strong>Retrieval-Augmented Generation (RAG)</strong> is a design pattern developed to curb LLM hallucinations by coupling the model with private external databases. Instead of relying solely on baseline training data, a RAG system works in three steps:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-4" id="con-rag-steps-grid">
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900 flex flex-col gap-1" id="con-rag-s1">
              <span className="text-[10px] font-mono font-bold text-emerald-400">01. INDEXING</span>
              <p className="text-[11px] text-slate-400 leading-normal">Documents are broken into chunks, converted into vector representations, and recorded inside high-dimensional spatial databases.</p>
            </div>
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900 flex flex-col gap-1" id="con-rag-s2">
              <span className="text-[10px] font-mono font-bold text-emerald-400">02. RETRIEVAL</span>
              <p className="text-[11px] text-slate-400 leading-normal">The user’s query is converted to a vector representation and matched against the index using cosine similarity equations.</p>
            </div>
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900 flex flex-col gap-1" id="con-rag-s3">
              <span className="text-[10px] font-mono font-bold text-emerald-400">03. GENERATION</span>
              <p className="text-[11px] text-slate-400 leading-normal">The top matching document sections are appended to the LLM prompt, forcing it to generate answers based on those segments.</p>
            </div>
          </div>
          <p className="text-slate-400">
            This works brilliantly for direct lookup inquiries (e.g., "What is our company name?"), but fails in high-stakes environments where dates, comparative performance limits, or multi-hop logical dependencies determine policy criteria.
          </p>
        </div>
      )
    },
    {
      id: 'rag-limitations',
      title: 'Limitations of Naive RAG',
      subtitle: 'Where Traditional Chains Fall Short',
      icon: AlertOctagon,
      badge: 'Structural Risks',
      badgeColor: 'bg-rose-500/10 text-rose-400 border border-rose-500/20',
      content: (
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans" id="con-lim-desc">
          <p>
            Traditional, naive RAG is a linear, unconditional pipeline: <code className="bg-slate-900 p-1 rounded px-1.5 text-xs text-rose-400 font-mono">Query → Vector DB → LLM</code>. If the retrieval step fails, the failure cascades silently directly into the answer window.
          </p>
          <ul className="space-y-3 my-4 pl-1" id="con-lim-list">
            <li className="flex gap-2.5 items-start" id="con-lim-item-1">
              <span className="bg-rose-500/20 text-rose-400 w-5 h-5 rounded-md flex items-center justify-center shrink-0 text-xs font-bold">1</span>
              <div>
                <strong className="text-slate-200">The Keyword-Tunnel Vision (Poor Retrieval Recall)</strong>
                <p className="text-xs text-slate-400 mt-0.5">If the query does not contain exact engineering terminology, standard vector searches fail to capture adjacent constraint charts.</p>
              </div>
            </li>
            <li className="flex gap-2.5 items-start" id="con-lim-item-2">
              <span className="bg-rose-500/20 text-rose-400 w-5 h-5 rounded-md flex items-center justify-center shrink-0 text-xs font-bold">2</span>
              <div>
                <strong className="text-slate-200">Contextual Poisoning & Irrelevance</strong>
                <p className="text-xs text-slate-400 mt-0.5">Standard pipelines force the LLM to answer using any high k-factor matching documents, even if they are noise or completely fail to resolve the core intent.</p>
              </div>
            </li>
            <li className="flex gap-2.5 items-start" id="con-lim-item-3">
              <span className="bg-rose-500/20 text-rose-400 w-5 h-5 rounded-md flex items-center justify-center shrink-0 text-xs font-bold">3</span>
              <div>
                <strong className="text-slate-200">The "Out-of-Bounds" Hallucination</strong>
                <p className="text-xs text-slate-400 mt-0.5">The LLM synthesizes empty assumptions for comparative terms because it has no mechanism to double-back, rewrite the question, or cross-check its figures before outputting.</p>
              </div>
            </li>
          </ul>
        </div>
      )
    },
    {
      id: 'agentic-rag',
      title: 'What is Agentic RAG?',
      subtitle: 'The Self-Corrective State-Machine Solution',
      icon: RefreshCw,
      badge: 'Level 2: Adaptive',
      badgeColor: 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20',
      content: (
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans" id="con-agentic-desc">
          <p>
            <strong>Agentic RAG</strong> reframes retrieval as an active multi-agent workflow containing <strong className="text-indigo-400">conditional loop-back networks</strong> and <strong className="text-indigo-400">self-grading algorithms</strong>. Instead of accepting the first vector DB output, an Agentic pipeline evaluates retrieved data quality dynamically.
          </p>
          <p>
            If the retrieved context is classified as lacking or irrelevant, the agentic state machine rejects the context, reformulates the search parameters, and query-retrieves again!
          </p>
          <div className="p-4 bg-indigo-950/20 border border-indigo-900/40 rounded-xl flex flex-col gap-2 my-2" id="con-agentic-loop">
            <h5 className="font-semibold text-xs text-indigo-300 font-sans">The Self-RAG Corrective Loop:</h5>
            <ol className="list-decimal pl-5 text-xs text-slate-400 space-y-1" id="con-agentic-loop-steps">
              <li><strong>Route:</strong> Filter queries immediately to find which target databases (policies, logs, QA) are relevant.</li>
              <li><strong>Grade Retrieval:</strong> Check if extracted chunks actually overlap with the prompt.</li>
              <li><strong>Re-Write:</strong> If context matches are poor, rewrite query strings and repeat searches.</li>
              <li><strong>Validate Grounding:</strong> Run self-grade assessments on the generated output to check for hallucinations.</li>
            </ol>
          </div>
        </div>
      )
    },
    {
      id: 'agent-roles',
      title: 'Active Agent Roles Defined',
      subtitle: 'Understanding the Core Cognitive Actors',
      icon: ShieldCheck,
      badge: 'Multi-Agent Network',
      badgeColor: 'bg-teal-500/10 text-teal-400 border border-teal-500/20',
      content: (
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans" id="con-roles-desc">
          <p>
            An Agentic RAG architecture assigns complex processing jobs to discrete AI micro-agents, each trained with customized system constraints:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" id="con-roles-grid">
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900" id="con-role-router">
              <div className="flex items-center gap-2 mb-1" id="role-r">
                <span className="w-2 h-2 rounded bg-violet-400 mr-0.5" />
                <span className="font-semibold text-xs text-slate-200">The Routing Agent</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">Reads user queries first. Classifies intent coordinates to route requests to specific indices (e.g. HR charts, API services, Web-search indexes).</p>
            </div>
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900" id="con-role-rewriter">
              <div className="flex items-center gap-2 mb-1" id="role-w">
                <span className="w-2 h-2 rounded bg-amber-400 mr-0.5" />
                <span className="font-semibold text-xs text-slate-200">The Query Optimizer</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">Translates dense and colloquial user prompts into clear search keywords, or splits composite queries into multi-step search streams.</p>
            </div>
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900" id="con-role-evaluator">
              <div className="flex items-center gap-2 mb-1" id="role-e">
                <span className="w-2 h-2 rounded bg-red-400 mr-0.5" />
                <span className="font-semibold text-xs text-slate-200">The Relevance Grader</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">Examines documents retrieved against user intentions. Scores quality and triggers corrective re-routing loops if data is insufficient.</p>
            </div>
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-900" id="con-role-grader">
              <div className="flex items-center gap-2 mb-1" id="role-g">
                <span className="w-2 h-2 rounded bg-teal-400" />
                <span className="font-semibold text-xs text-slate-200">The Hallucination Auditor</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">Scans the final generated paragraph. Compares statement fragments directly with facts inside documents to eliminate generated fictions.</p>
            </div>
          </div>
        </div>
      )
    }
  ];

  const active = concepts.find(c => c.id === activeConcept) || concepts[0];
  const Icon = active.icon;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 bg-slate-950 border border-slate-900 rounded-2xl p-6 shadow-xl" id="info-panel-wrapper">
      {/* Concept Directory Links */}
      <div className="lg:col-span-1 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-x-visible pb-3 lg:pb-0 scrollbar-none" id="concept-directory">
        {concepts.map((concept) => {
          const ConceptIcon = concept.icon;
          const isSelected = activeConcept === concept.id;
          return (
            <button
              key={concept.id}
              id={`concept-tab-${concept.id}`}
              onClick={() => setActiveConcept(concept.id)}
              className={`flex items-center gap-3 px-4 py-3 text-left rounded-xl transition w-full shrink-0 lg:shrink-1 ${
                isSelected 
                  ? 'bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-medium' 
                  : 'bg-slate-900/30 hover:bg-slate-900/60 border border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <ConceptIcon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
              <span className="text-xs font-sans tracking-tight truncate">{concept.title}</span>
            </button>
          );
        })}
      </div>

      {/* active details block */}
      <div className="lg:col-span-3 flex flex-col bg-slate-900/30 border border-slate-900 rounded-2xl p-6 min-h-[300px]" id="concept-explanation-box">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900 pb-4 mb-4" id="explanation-header">
          <div className="flex items-center gap-3" id="explanation-title-wrap">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 shrink-0" id="explanation-icon-wrap">
              <Icon className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h4 className="font-semibold text-sm sm:text-base text-slate-100 font-sans" id="explanation-title">
                {active.title}
              </h4>
              <p className="text-xs text-slate-500 font-sans mt-0.5" id="explanation-subtitle">
                {active.subtitle}
              </p>
            </div>
          </div>
          <span className={`text-[10px] font-mono font-bold tracking-wider py-1 px-3 rounded-full shrink-0 text-center uppercase md:self-center ${active.badgeColor}`} id="explanation-badge">
            {active.badge}
          </span>
        </div>

        {/* Dynamic Concept Explanation */}
        <div className="flex-1 overflow-y-auto" id="explanation-inner-content">
          {active.content}
        </div>
      </div>
    </div>
  );
};

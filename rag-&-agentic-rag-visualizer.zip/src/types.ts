export interface DocumentChunk {
  id: string;
  source: string;
  content: string;
  relevanceScore?: number; // mock score
}

export interface Dataset {
  id: string;
  name: string;
  description: string;
  icon: string; // Lucide icon identity
  documents: {
    source: string;
    text: string;
    category: string;
  }[];
  chunks: DocumentChunk[];
}

export interface RAGStep {
  id: string;
  nodeId: string;
  title: string;
  description: string;
  status: 'pending' | 'active' | 'completed' | 'failed' | 'warning';
  outputDetails?: string; // Rich logs/text
  durationMs: number;
}

export interface SimulationResult {
  pipelineType: 'standard' | 'agentic';
  query: string;
  steps: RAGStep[];
  retrievedChunks: DocumentChunk[];
  finalAnswer: string;
  citations: string[];
  executionTimeMs: number;
  costEstimateCents: number;
}

export interface GraphNode {
  id: string;
  label: string;
  role: string;
  x: number; // percentage
  y: number; // percentage
  type: 'input' | 'process' | 'agent' | 'database' | 'output';
  description: string;
}

export interface GraphEdge {
  from: string;
  to: string;
  label?: string;
  animated?: boolean;
}

import React, { useState, useEffect, useRef, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  DATASETS, PRESET_RUNS, CustomPresetRun 
} from './data/datasets';
import { 
  Play, RotateCcw, ArrowRight, BookOpen, Layers, Terminal, 
  HelpCircle, ChevronRight, FileText, CheckCircle2, AlertTriangle, 
  Clock, Coins, Flame, Search, RefreshCw, MessageSquare
} from 'lucide-react';
import { FlowVisualizer } from './components/FlowVisualizer';
import { CodeComparison } from './components/CodeComparison';
import { InfoPanel } from './components/InfoPanel';
import { ChatbotSandbox } from './components/ChatbotSandbox';
import { RAGStep, DocumentChunk, SimulationResult } from './types';

export default function App() {
  // Config States
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('health-benefits');
  const [pipelineType, setPipelineType] = useState<'standard' | 'agentic'>('agentic');
  const [customQuery, setCustomQuery] = useState<string>('');
  
  // Simulation Active states
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [activeStepLogs, setActiveStepLogs] = useState<RAGStep[]>([]);
  const [retrievedDocs, setRetrievedDocs] = useState<DocumentChunk[]>([]);
  const [finalAnswer, setFinalAnswer] = useState<string>('');
  const [executionTime, setExecutionTime] = useState<number>(0);
  const [costEstimate, setCostEstimate] = useState<number>(0);
  const [citations, setCitations] = useState<string[]>([]);
  
  // Statuses
  const [isLoadingLive, setIsLoadingLive] = useState<boolean>(false);
  const [activeViewTab, setActiveViewTab] = useState<'visualizer' | 'code' | 'concepts' | 'chatbot'>('chatbot');
  const [currentStepIndexLive, setCurrentStepIndexLive] = useState<number>(-1);
  const [liveLoadingMessage, setLiveLoadingMessage] = useState<string>('');

  // active preset
  const [selectedPresetIndex, setSelectedPresetIndex] = useState<number>(0);

  // Time reference for automatic stepper playbacks
  const autoPlayTimerRef = useRef<NodeJS.Timeout | null>(null);

  const dataset = DATASETS.find(d => d.id === selectedDatasetId) || DATASETS[0];

  // Get active preset run corresponding to dataset selection
  const activePreset = PRESET_RUNS.find(p => p.datasetId === selectedDatasetId) || PRESET_RUNS[0];

  // Sync preset choice when dataset is altered
  useEffect(() => {
    const matchedPresetIndex = PRESET_RUNS.findIndex(p => p.datasetId === selectedDatasetId);
    if (matchedPresetIndex !== -1) {
      setSelectedPresetIndex(matchedPresetIndex);
      resetSimulation();
    }
  }, [selectedDatasetId]);

  // Handle preset query clicks
  const loadPresetQuery = (preset: CustomPresetRun) => {
    setCustomQuery('');
    resetSimulation();
  };

  // Reset active simulation parameters
  const resetSimulation = () => {
    if (autoPlayTimerRef.current) {
      clearInterval(autoPlayTimerRef.current);
    }
    setIsPlaying(false);
    setCurrentStepIndex(-1);
    setActiveStepLogs([]);
    setRetrievedDocs([]);
    setFinalAnswer('');
    setExecutionTime(0);
    setCostEstimate(0);
    setCitations([]);
  };

  // Setup the configuration for the simulation (either standard or agentic preset state)
  const initializeSimulation = () => {
    resetSimulation();
    
    const preset = PRESET_RUNS[selectedPresetIndex];
    const isStandard = pipelineType === 'standard';
    const runData = isStandard ? preset.standardRun : preset.agenticRun;

    // Map source mock strings in retrieved files to full chunks info
    const matchedChunks = dataset.chunks.filter(chk => 
      runData.retrievedChunks.includes(chk.source)
    );

    // Build steps lists conforming to type
    const initialSteps: RAGStep[] = runData.steps.map((step, idx) => ({
      id: `step-${idx}`,
      nodeId: step.nodeId,
      title: step.nodeId === 'query-refinement' ? 'Search Optimization' : step.nodeId === 'doc-evaluator' ? 'Relevance Checklist' : step.nodeId.toUpperCase(),
      description: step.detail,
      status: step.status as any,
      durationMs: Math.floor(Math.random() * 150) + 50,
      outputDetails: step.detail
    }));

    // Trigger sequential loading
    setActiveStepLogs(initialSteps);
    setRetrievedDocs(matchedChunks);
    setFinalAnswer(runData.answer);
    setExecutionTime(isStandard ? 450 : 1240);
    setCostEstimate(isStandard ? 0.015 : 0.078);
    setCitations(runData.retrievedChunks);
    setCurrentStepIndex(0);
    setIsPlaying(true);
  };

  // Perform automatic stepper interval
  useEffect(() => {
    if (isPlaying && currentStepIndex >= 0 && currentStepIndex < activeStepLogs.length - 1) {
      autoPlayTimerRef.current = setTimeout(() => {
        setCurrentStepIndex(prev => prev + 1);
      }, 2300); // 2.3 seconds per step gives perfect reading pace
    } else if (currentStepIndex === activeStepLogs.length - 1) {
      setIsPlaying(false);
    }

    return () => {
      if (autoPlayTimerRef.current) {
        clearTimeout(autoPlayTimerRef.current);
      }
    };
  }, [isPlaying, currentStepIndex, activeStepLogs]);

  // Forward manual step controller
  const navigateNextStep = () => {
    if (currentStepIndex < activeStepLogs.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    }
  };

  // Backward manual step controller
  const navigatePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  // Live Query backend API trigger
  const triggerLiveQuery = async (e: FormEvent) => {
    e.preventDefault();
    if (!customQuery.trim()) return;

    resetSimulation();
    setIsLoadingLive(true);
    setLiveLoadingMessage("Routing inquiry request to Agentic Controller...");

    // Smooth mock transitions on loading overlay
    const loadingStates = [
      "Router Agent scanning classification indices...",
      "Generating high-dimensional semantic search query transforms...",
      "Executing sub-query vector matches against index databases...",
      "Cognitive Evaluation Agent testing document chunk compliance...",
      "Context discrepancy detected - triggers re-writing agent fallbacks...",
      "Re-executing semantic searches with corrected keywords...",
      "Verified contexts approved! Commencing generation templates...",
      "Synthesis complete. Pushing response to hallucination grounding auditors..."
    ];

    let lIndex = 0;
    const interval = setInterval(() => {
      if (lIndex < loadingStates.length) {
        setLiveLoadingMessage(loadingStates[lIndex]);
        lIndex++;
      }
    }, 1800);

    try {
      const response = await fetch("/api/rag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datasetId: selectedDatasetId,
          query: customQuery,
          pipelineType: pipelineType
        }),
      });

      const result: SimulationResult = await response.json();
      
      clearInterval(interval);
      setIsLoadingLive(false);

      // Populate simulation responses
      setActiveStepLogs(result.steps);
      setRetrievedDocs(result.retrievedChunks);
      setFinalAnswer(result.finalAnswer);
      setExecutionTime(result.executionTimeMs);
      setCostEstimate(result.costEstimateCents);
      setCitations(result.citations || []);
      
      // Begin simulation showcase starting from first step
      setCurrentStepIndex(0);
      setIsPlaying(true);
    } catch (err) {
      console.error(err);
      clearInterval(interval);
      setIsLoadingLive(false);
      // Fail alert fallback
      alert("Encountered connection difficulties compiling live query. Running fallback offline demonstration.");
      initializeSimulation();
    }
  };

  // Highlight specific node identifier in flowchart corresponding to selected step idx
  const activeNodeIdInGraph = activeStepLogs[currentStepIndex]?.nodeId || null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-300 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200" id="app-root-visualizer">
      {/* High Density Header Section */}
      <header className="border-b border-slate-800 bg-slate-950 px-6 py-4 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 sticky top-0 z-50 shadow-sm" id="app-header">
        <div>
          <h1 className="text-xl font-bold text-white font-display tracking-tight flex items-center gap-2">
            <span className="w-3 h-3 bg-cyan-500 rounded-full animate-pulse"></span>
            RETRIEVAL LABS / <span className="text-cyan-400 font-mono text-lg font-semibold">ARCHITECT V1.0</span>
          </h1>
          <p className="text-[10px] text-slate-500 font-mono mt-1 uppercase tracking-widest italic">Diagnostic Comparative Analysis: Standard vs. Agentic Workflow</p>
        </div>

        {/* Global tab manager */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/60 rounded-xl border border-slate-800 w-full xl:w-auto overflow-x-auto" id="global-tabs">
          <button
            id="tab-chatbot"
            onClick={() => setActiveViewTab('chatbot')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold font-sans tracking-wide transition-all cursor-pointer ${
              activeViewTab === 'chatbot' 
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm shadow-cyan-950/20' 
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            Chatbot Sandbox
          </button>
          <button
            id="tab-visualizer"
            onClick={() => setActiveViewTab('visualizer')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold font-sans tracking-wide transition-all cursor-pointer ${
              activeViewTab === 'visualizer' 
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm shadow-cyan-950/20' 
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            Interactive Visualizer
          </button>
          <button
            id="tab-code"
            onClick={() => setActiveViewTab('code')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold font-sans tracking-wide transition-all cursor-pointer ${
              activeViewTab === 'code' 
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm shadow-cyan-950/20' 
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            View Under the Hood Code
          </button>
          <button
            id="tab-concepts"
            onClick={() => setActiveViewTab('concepts')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold font-sans tracking-wide transition-all cursor-pointer ${
              activeViewTab === 'concepts' 
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm shadow-cyan-950/20' 
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Explanation Center
          </button>
        </div>

        <div className="flex gap-4 shrink-0" id="header-diagnostics">
          <div className="px-3 py-1 bg-slate-905 border border-slate-800 rounded text-[11px] font-mono bg-slate-900/60 shadow-sm">
            <span className="text-slate-500">LATENCY:</span> <span className="text-emerald-400 font-bold">{currentStepIndex >= 0 ? `${executionTime}ms` : '142ms'}</span>
          </div>
          <div className="px-3 py-1 bg-slate-905 border border-slate-800 rounded bg-slate-900/60 text-[11px] font-mono shadow-sm">
            <span className="text-slate-500">FEES:</span> <span className="text-cyan-400 font-bold">{currentStepIndex >= 0 ? `${costEstimate.toFixed(3)}¢` : '0.045¢'}</span>
          </div>
        </div>
      </header>

      {/* Main Workspaces panels */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto px-4 lg:px-8 py-6 flex flex-col gap-6" id="app-workspace-body">
        
        {activeViewTab === 'visualizer' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="visualizer-grid">
            
            {/* LEFT COLUMN: Controls & Document Workspace */}
            <div className="lg:col-span-1 flex flex-col gap-6" id="workspace-sidebar">
              
              {/* Select Knowledge Database Corpus Segment */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-sm" id="corpus-selector-card">
                <div className="flex items-center gap-2 mb-4" id="corpus-header">
                  <BookOpen className="w-4 h-4 text-slate-400 animate-pulse" />
                  <h3 className="font-semibold text-xs tracking-wider text-slate-400 uppercase font-sans">
                    1. CHOOSE PRIVATE CORPUS
                  </h3>
                </div>

                <div className="flex flex-col gap-2.5" id="corpus-list flex">
                  {DATASETS.map((d) => {
                    const isSelected = selectedDatasetId === d.id;
                    return (
                      <button
                        key={d.id}
                        id={`corpus-card-${d.id}`}
                        onClick={() => {
                          setSelectedDatasetId(d.id);
                          setCustomQuery('');
                        }}
                        className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
                          isSelected 
                            ? 'bg-cyan-950/20 border-cyan-500/50 text-cyan-200 ring-1 ring-cyan-500/10' 
                            : 'bg-slate-900/30 hover:bg-slate-900/60 border-slate-800 text-slate-400'
                        }`}
                      >
                        <h4 className="font-bold text-xs font-sans tracking-tight text-white mb-1">
                          {d.name}
                        </h4>
                        <p className="text-[10px] leading-relaxed text-slate-400 line-clamp-2">
                          {d.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* RAG Strategy Select Panel */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-sm" id="strategy-selector-card">
                <div className="flex items-center gap-2 mb-4" id="strategy-header">
                  <Flame className="w-4 h-4 text-amber-500" />
                  <h3 className="font-semibold text-xs tracking-wider text-slate-400 uppercase font-sans">
                    2. RAG RETRIEVAL STRATEGY
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-2.5" id="strategy-split-grid">
                  <button
                    id="strat-std-btn"
                    onClick={() => {
                      setPipelineType('standard');
                      resetSimulation();
                    }}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      pipelineType === 'standard'
                        ? 'bg-slate-900 border-slate-700 text-white font-semibold shadow-inner'
                        : 'bg-slate-900/10 hover:bg-slate-900/30 border-transparent text-slate-500 hover:text-slate-400'
                    }`}
                  >
                    <span className="text-xs block font-sans">Naive RAG</span>
                    <span className="text-[8px] font-mono text-slate-500 block mt-0.5 font-normal">One-Shot Vector Pull</span>
                  </button>

                  <button
                    id="strat-agentic-btn"
                    onClick={() => {
                      setPipelineType('agentic');
                      resetSimulation();
                    }}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      pipelineType === 'agentic'
                        ? 'bg-amber-950/20 border-amber-500/50 text-amber-400 font-semibold ring-1 ring-amber-500/10'
                        : 'bg-slate-900/10 hover:bg-slate-900/30 border-transparent text-slate-500 hover:text-slate-400'
                    }`}
                  >
                    <span className="text-xs block font-sans">Agentic RAG</span>
                    <span className="text-[8px] font-mono text-amber-500 block mt-0.5 font-bold">Multi-Agent Loop</span>
                  </button>
                </div>
              </div>

              {/* Query Selection & Playground Sandbox */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-sm flex-1 flex flex-col" id="query-sandbox-card">
                <div className="flex items-center gap-2 mb-3 shrink-0" id="sandbox-header">
                  <Search className="w-4 h-4 text-slate-400 animate-pulse" />
                  <h3 className="font-semibold text-xs tracking-wider text-slate-400 uppercase font-sans">
                    3. TRIGGER SIMULATION RUN
                  </h3>
                </div>

                {/* Preset sample button wrapper */}
                <div className="p-3 bg-slate-950/85 rounded-xl border border-slate-850/80 mb-4 shrink-0" id="preset-trigger-box">
                  <span className="text-[9px] font-mono text-slate-500 font-bold block mb-2 uppercase">PRESET Walkthrough Inquiries:</span>
                  <div className="flex flex-col gap-1.5" id="preset-list">
                    <button
                      id="load-preset-btn"
                      onClick={() => {
                        setCustomQuery('');
                        initializeSimulation();
                      }}
                      className="p-2.5 rounded-lg text-left bg-cyan-500/5 border border-cyan-500/20 text-[11px] text-cyan-300 transition-colors hover:bg-cyan-500/10 w-full flex items-center justify-between cursor-pointer"
                    >
                      <div className="truncate pr-2 font-medium" id="preset-lbl-text">
                        "{activePreset.query}"
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    </button>
                  </div>
                  <span className="text-[9px] text-slate-500 leading-normal block mt-2" id="preset-explainer-log">
                    💡 <em>Click the preset button above to watch how Naive RAG fails to capture key criteria limits, but Agentic RAG auto-corrects!</em>
                  </span>
                </div>

                {/* Custom query input sandbox */}
                <form onSubmit={triggerLiveQuery} className="flex-1 flex flex-col justify-end mt-4 lg:mt-auto gap-3 border-t border-slate-900 pt-4" id="sandbox-custom-form">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-tight block" id="custom-query-lbl">
                    OR TEST ANY CUSTOM QUERY:
                  </label>
                  <textarea
                    id="custom-query-box"
                    value={customQuery}
                    onChange={(e) => setCustomQuery(e.target.value)}
                    placeholder="e.g. Can we get fully reimbursed for diagnostic treatments past June?"
                    className="w-full h-24 bg-slate-950 p-3 text-xs border border-slate-800 rounded-xl focus:outline-none focus:border-cyan-600 focus:ring-1 focus:ring-cyan-600 text-slate-300 placeholder:text-slate-700 font-sans resize-none"
                  />
                  <button
                    type="submit"
                    id="submit-query-btn"
                    disabled={!customQuery.trim() || isLoadingLive}
                    className="w-full p-2.5 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold hover:bg-cyan-400 active:bg-cyan-600 disabled:bg-slate-900 disabled:text-slate-600 transition flex items-center justify-center gap-2 shadow-md shadow-cyan-950/20 cursor-pointer"
                  >
                    <span>Analyze query with Gemini AI</span>
                    <Play className="w-3 h-3 fill-current text-slate-950" />
                  </button>
                </form>

              </div>
            </div>

            {/* MID-COLUMN: Flow Schematic Visualizer */}
            <div className="lg:col-span-3 flex flex-col gap-6" id="workspace-center">
              
              {/* Flowchart visualizer mapping coordinates */}
              <div className="flex-1 min-h-[450px] lg:min-h-[500px]" id="flow-visualizer-outer">
                <FlowVisualizer
                  pipelineType={pipelineType}
                  activeNodeId={activeNodeIdInGraph}
                  steps={activeStepLogs}
                  currentStepIndex={currentStepIndex}
                />
              </div>

              {/* Simulation Playback Console */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-5 shadow-sm" id="playback-console">
                
                {/* Steppers controls */}
                <div className="flex items-center gap-3 w-full md:w-auto" id="playback-controls">
                  <button
                    id="prev-step-btn"
                    onClick={navigatePrevStep}
                    disabled={currentStepIndex <= 0}
                    className="px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-semibold disabled:opacity-30 hover:bg-slate-900 text-slate-300 flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    Back
                  </button>

                  <div className="bg-slate-950/80 border border-slate-850 rounded-lg p-2 px-4 text-xs font-mono text-center flex-1 md:flex-initial text-cyan-400 font-semibold" id="playback-state-lbl">
                    Step [0{currentStepIndex + 1}/0{activeStepLogs.length || 0}]
                  </div>

                  <button
                    id="next-step-btn"
                    onClick={navigateNextStep}
                    disabled={currentStepIndex >= activeStepLogs.length - 1}
                    className="px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-semibold disabled:opacity-30 hover:bg-slate-900 text-slate-300 flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    Skip
                  </button>

                  <button
                    id="reset-playback-btn"
                    onClick={resetSimulation}
                    className="p-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-400 hover:text-slate-200 shrink-0 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>

                {/* Diagnostic metrics readout panel */}
                <div className="flex gap-6 items-center w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 border-slate-900 pt-3 md:pt-0" id="playback-metrics">
                  <div className="flex items-center gap-2" id="metric-latency">
                    <Clock className="w-4 h-4 text-slate-500 animate-pulse" />
                    <div>
                      <span className="text-[9px] font-mono text-slate-500 font-bold block">SIMULATED TIME</span>
                      <span className="text-xs font-mono font-semibold text-emerald-400">
                        {currentStepIndex >= 0 ? `${executionTime} ms` : '142 ms'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2" id="metric-costs">
                    <Coins className="w-4 h-4 text-slate-500" />
                    <div>
                      <span className="text-[9px] font-mono text-slate-500 font-bold block">COMPUTATION FEES</span>
                      <span className="text-xs font-mono font-semibold text-cyan-400">
                        {currentStepIndex >= 0 ? `${costEstimate.toFixed(3)}¢` : '0.045¢'}
                      </span>
                    </div>
                  </div>
                </div>

              </div>

              {/* Bottom detail displays (Answer Output & Citations log) */}
              <div className="grid grid-cols-1 xl:grid-cols-5 gap-6" id="response-documents-layout">
                
                {/* Generation answers console */}
                <div className="xl:col-span-3 bg-slate-900/40 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[300px]" id="answer-generation-console">
                  <div id="answer-console-header">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-3.5 mb-4" id="answer-header-wrap">
                      <div className="flex items-center gap-2" id="answer-title-block">
                        <CheckCircle2 className="w-4.5 h-4.5 text-cyan-400" />
                        <h4 className="font-bold text-xs tracking-wider text-slate-305 uppercase font-sans text-slate-200">
                          GENERATED ANSWER VIEWPORT
                        </h4>
                      </div>
                      <div className="p-1 px-3 rounded bg-slate-950 border border-slate-800 text-[10px] font-mono text-cyan-400 capitalize" id="answer-strategy-indicator">
                        {pipelineType === 'agentic' ? 'LOOP-CONTROL' : 'LINEAR-PROC'}
                      </div>
                    </div>

                    {/* Final text results render */}
                    <div className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed min-h-[140px] select-text" id="answer-viewport-text">
                      <AnimatePresence mode="wait">
                        {currentStepIndex === activeStepLogs.length - 1 ? (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="whitespace-pre-line text-slate-200"
                            id="render-actual-text"
                          >
                            {finalAnswer}
                          </motion.div>
                        ) : currentStepIndex >= 0 ? (
                          <div className="text-slate-500 italic py-6 select-none animate-pulse text-center w-full font-mono text-xs" id="stream-generating-anim">
                            ⚙ Processing active pipeline context... Generative output is synthesized instantly upon step completion.
                          </div>
                        ) : (
                          <div className="text-slate-500 italic py-8 text-center text-xs" id="empty-state-answer">
                            💡 Trigger standard or agentic calculations on your datasets using standard preset or custom Gemini entries above to display visual step details and answers.
                          </div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  {/* Grounding audits and verify labels */}
                  {currentStepIndex === activeStepLogs.length - 1 && (
                    <div className="mt-4 border-t border-slate-800 pt-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shrink-0" id="answer-footer">
                      <div className="flex items-center gap-2 text-xs text-slate-400" id="veracity-seal">
                        {pipelineType === 'agentic' ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 animate-bounce" />
                            <span className="text-emerald-400 font-mono text-[10px] font-bold tracking-wider">✓ 100% GROUNDED STATE AUDIT PASSED</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                            <span className="text-amber-500 font-mono text-[10px] font-bold">⚠ UNCHECKED NAIVE SYNTHESIS (NO AUDITS)</span>
                          </>
                        )}
                      </div>
                      {citations.length > 0 && (
                        <div className="flex gap-1.5 flex-wrap" id="citations-pills">
                          <span className="text-[9px] font-mono text-slate-500 self-center uppercase mr-1">Retrieved Sources:</span>
                          {citations.map((cite, i) => (
                            <span key={i} className="text-[10px] font-mono p-1 px-2.5 bg-slate-950 border border-slate-800 rounded text-slate-400" id={`cite-pill-${i}`}>
                              {cite}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Retrieved context knowledge base chunks cards */}
                <div className="xl:col-span-2 bg-slate-900/40 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col h-full min-h-[300px]" id="extracted-knowledge-box">
                  <div className="flex items-center gap-2 border-b border-slate-800 pb-3.5 mb-4 shrink-0" id="kb-header">
                    <FileText className="w-5 h-5 text-slate-500" />
                    <h4 className="font-bold text-xs tracking-wider text-slate-400 uppercase font-sans">
                      RETRIEVED DATA CONTEXT
                    </h4>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-3.5 max-h-[200px] xl:max-h-[220px]" id="kb-scroller">
                    {currentStepIndex >= 0 && retrievedDocs.length > 0 ? (
                      retrievedDocs.map((doc, idx) => (
                        <div key={idx} id={`kb-chunk-card-${idx}`} className="p-3.5 bg-slate-950/60 rounded-xl border border-slate-850 text-[11px] leading-relaxed text-slate-350 select-text hover:bg-slate-900/20 transition-colors">
                          <div className="flex justify-between items-center mb-1.5 border-b border-slate-850/30 pb-1" id={`kb-chunk-meta-${idx}`}>
                            <span className="font-mono text-[9px] font-bold text-cyan-400 truncate max-w-[130px]">{doc.source}</span>
                            <span className="text-[8px] font-mono text-slate-500 border border-slate-800 bg-slate-950/40 px-1 rounded uppercase">Segment {idx + 1}</span>
                          </div>
                          <p className="font-sans font-light tracking-wide">{doc.content}</p>
                        </div>
                      ))
                    ) : (
                      <div className="text-xs text-slate-600 italic text-center py-12 font-mono" id="kb-empty-state">
                        ◌ No context chunks loaded in memory index yet.
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Bottom Analytics / Console Bar matching design theme */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mt-2" id="density-analytics-bar">
                
                {/* 1. Self-Correction Ability progress graph */}
                <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 flex flex-col justify-between" id="analytics-self-correction">
                  <div>
                    <h5 className="text-[10px] text-slate-500 uppercase font-mono font-bold tracking-wider mb-2 flex items-center justify-between">
                      <span>Self-Correction Ability</span>
                      <span className="text-[8px] text-slate-400 border border-slate-800 px-1 rounded">ACCURACY TEST</span>
                    </h5>
                    
                    <div className="space-y-2 mt-3" id="self-correction-bars">
                      <div>
                        <div className="flex justify-between text-[9px] mb-1">
                          <span className="text-slate-400">Naive RAG (Baseline)</span>
                          <span className="text-slate-400 font-mono">10%</span>
                        </div>
                        <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-900/60">
                          <div className="h-full bg-cyan-500 rounded-full" style={{ width: '10%' }}></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[9px] mb-1">
                          <span className="text-emerald-400 font-semibold">Agentic RAG (Loop)</span>
                          <span className="text-amber-400 font-bold font-mono">95%</span>
                        </div>
                        <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-900/60">
                          <div className={`h-full bg-amber-500 rounded-full ${isPlaying ? 'animate-pulse' : ''}`} style={{ width: '95%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Complex Query Resolvability card */}
                <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 flex flex-col justify-between" id="complex-query-resolvability">
                  <div>
                    <h5 className="text-[10px] text-slate-500 uppercase font-mono font-bold tracking-wider mb-1">
                      Complex Query Resolvability
                    </h5>
                    <div className="text-2xl font-mono font-bold text-white tracking-tight mt-1">
                      {pipelineType === 'agentic' ? '88.4' : '38.2'}
                      <span className="text-slate-605 text-xs font-normal text-slate-500">/100</span>
                    </div>
                    <div className="text-[9px] text-emerald-400 mt-1 flex items-center gap-1 font-mono">
                      <span>✓</span>
                      <span>
                        {pipelineType === 'agentic' 
                          ? '+12.4% over Standard RAG baseline' 
                          : 'Baseline keyword vectors only'}
                      </span>
                    </div>
                  </div>
                  <div className="text-[8px] text-slate-500 leading-normal border-t border-slate-800 pt-2 font-mono">
                    BENCHMARK IN RETRIEVAL DEVIATION GRADES
                  </div>
                </div>

                {/* 3 & 4. System Diagnostics log console */}
                <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 col-span-1 md:col-span-2 flex flex-col justify-between gap-3" id="system-diagnostics-console">
                  <div>
                    <h5 className="text-[10px] text-slate-500 uppercase font-mono font-bold tracking-wider mb-2 flex justify-between items-center">
                      <span>System Diagnostics & Adaptive Telemetry</span>
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    </h5>
                    
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-3" id="diag-layout">
                      <div className="md:col-span-3 border border-slate-800/60 bg-black/40 p-2.5 rounded-lg font-mono text-[9px] text-slate-400 leading-normal min-h-[56px] select-all">
                        <div className="text-slate-500">// ACTIVE RETRIEVAL LAB ENVIRONMENT</div>
                        <div>$ agentic_retrieval_status: <span className="text-cyan-400 font-bold">{isPlaying ? 'active_routing' : isLoadingLive ? 'running_gemini' : 'idle_standby'}</span></div>
                        <div>$ cache_hit_rate: <span className="text-amber-400">0.82</span> | recursive_depth_max: <span className="text-indigo-400">5</span></div>
                        <div>$ current_node_pointer: <span className="text-white font-bold">{activeNodeIdInGraph ? activeNodeIdInGraph : 'null'}</span></div>
                      </div>
                      
                      <div className="md:col-span-2 flex items-center justify-center border border-slate-800 rounded-lg bg-slate-950 hover:bg-slate-900 transition-colors p-3 group">
                        <button 
                          onClick={() => {
                            if (customQuery.trim()) {
                              const e = { preventDefault: () => {} } as React.FormEvent;
                              triggerLiveQuery(e);
                            } else {
                              initializeSimulation();
                            }
                          }}
                          className="px-3 py-2 w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold uppercase tracking-wider border border-cyan-500/30 rounded transition active:scale-95 text-center cursor-pointer"
                        >
                          {isPlaying ? '⚡ RUNNING...' : '▶ EXECUTING'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>
        )}

        {/* tab 1 view: Chatbot sandbox playground */}
        {activeViewTab === 'chatbot' && (
          <div id="tab-chatbot-view" className="h-full">
            <ChatbotSandbox 
              selectedDatasetId={selectedDatasetId} 
              onDatasetChange={setSelectedDatasetId} 
            />
          </div>
        )}

        {/* tab 2 view: Code block comparison */}
        {activeViewTab === 'code' && (
          <div id="tab-code-view" className="h-full">
            <CodeComparison />
          </div>
        )}

        {/* tab 3 view: Conceptual explanation base */}
        {activeViewTab === 'concepts' && (
          <div id="tab-concepts-view" className="h-full">
            <InfoPanel />
          </div>
        )}

      </main>

      <AnimatePresence>
        {isLoadingLive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-[100] flex flex-col items-center justify-center p-6"
            id="loading-overlay-outer"
          >
            <div className="max-w-md text-center flex flex-col items-center" id="loading-overlay-box">
              <div className="w-16 h-16 rounded-3xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-6 shadow-xl" id="loading-icon-wrap">
                <RefreshCw className="w-8 h-8 animate-spin" />
              </div>
              
              <h3 className="text-lg font-bold text-white mb-2" id="loading-overlay-title">
                Analyzing with Gemini AI Agentic Engine
              </h3>
              
              <div className="text-xs font-mono text-cyan-400 bg-cyan-500/15 p-3 px-6 rounded-2xl border border-cyan-500/20 transition-all duration-300 min-h-[3.5rem] flex items-center justify-center text-center max-w-sm" id="loading-state-details">
                {liveLoadingMessage}
              </div>
              
              <p className="text-[11px] text-slate-500 leading-normal mt-6 max-w-xs" id="loading-tip">
                Please wait. This executes standard or multi-agent routing configurations across your custom database segments dynamically on our server wrapper.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Simple elegant page footer */}
      <footer className="border-t border-slate-950 bg-[#02050f]/80 py-4 px-6 mt-auto text-center font-mono text-[10px] text-slate-600" id="app-footer">
        © 2026 RAG & Agentic RAG Visualizer. Explaining correction mechanisms and multi-agent loops. Built for high fidelity local simulations.
      </footer>
    </div>
  );
}

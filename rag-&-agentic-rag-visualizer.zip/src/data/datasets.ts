import { Dataset } from '../types';

export const DATASETS: Dataset[] = [
  {
    id: 'health-benefits',
    name: 'AuraSpace Health Benefits Guide',
    description: 'Corporate insurance policy with detailed mental health riders, strict pre-approval dates, and specific policy limits.',
    icon: 'ShieldAlert',
    documents: [
      {
        source: 'HR-Policy-Sec-4.pdf',
        category: 'General Reimbursement',
        text: 'Standard mental health therapy sessions are reimbursed at 80% of costs, up to a maximum limit of $1,000 per fiscal year. Standard claims must be submitted within 60 days of the session.'
      },
      {
        source: 'HR-Policy-Rider-12B.pdf',
        category: 'Specialized Assessment Reimbursement',
        text: 'Rider 12B covers specialized cognitive and neuro-divergent assessment processes (including ADHD and Autism diagnostic batteries). Reimbursements are covered up to 100% (max $3,000) ONLY if a pre-approval request is submitted and authorized by June 30th of the current plan year. Requests filed after June 30th are strictly excluded from Rider 12B and processed under standard therapy limits (80% up to $1,000 max).'
      },
      {
        source: 'HR-Calendar-2026.pdf',
        category: 'Policy Timelines',
        text: 'The 2026 plan calendar states that the mid-year policy benefit adjustments occur on July 1st. All authorized pre-approvals for diagnostic assessments must be active in the system prior to this date. Plan year runs from Jan 1st to Dec 31st.'
      }
    ],
    get chunks() {
      return this.documents.map((doc, idx) => ({
        id: `chunk-${this.id}-${idx}`,
        source: doc.source,
        content: doc.text
      }));
    }
  },
  {
    id: 'quantum-vc',
    name: 'AetherQ Physics Patent Portfolio',
    description: 'Highly mathematical and proprietary descriptions of superconducting qubits and fluxonium circuits.',
    icon: 'Cpu',
    documents: [
      {
        source: 'Patent-AQ-9082.pdf',
        category: 'Qubit Architecture',
        text: 'The AetherQ processor utilizes proprietary superconducting transmon qubits. These transmons operate at a base Josephson energy ratio of Ej/Ec ≈ 50, yielding average coherence times (T2) of 120 microseconds under cryogenic shielding at 10mK.'
      },
      {
        source: 'Lab-Report-Fluxonium.pdf',
        category: 'Experimental Designs',
        text: 'Experimental designs using fluxonium-style circuits (heavy fluxonium utilizing superinductance chains) have demonstrated remarkable resilience to charge noise. Our prototype Flux-9 core exhibits T2 coherence times exceeding 1.4 milliseconds (1,400 microseconds), representing a >10x improvement over standard transmons, but requires a tuned microwave flux-bias configuration operating strictly between 0.49 and 0.51 flux quanta.'
      },
      {
        source: 'Investor-Pitch-Q2.pdf',
        category: 'Commercial Milestones',
        text: 'AetherQ commercial quantum hardware is scheduled to transition from transmon chips to Flux-9 fluxonium cores by Q4 2026. This scaling milestone will increase logical qubit fidelity from 99.9% to 99.99%',
      }
    ],
    get chunks() {
      return this.documents.map((doc, idx) => ({
        id: `chunk-${this.id}-${idx}`,
        source: doc.source,
        content: doc.text
      }));
    }
  },
  {
    id: 'ev-safety',
    name: 'OmniDrive EV Safety & Telematics Logs',
    description: 'Technical recall records, temperature thresholds, and hydraulic braking reports.',
    icon: 'Car',
    documents: [
      {
        source: 'Recall-Notification-2025-A.pdf',
        category: 'Thermal Management',
        text: 'OmniDrive vehicles manufactured between 2023 and 2025 have an active service bulletin regarding low-temperature performance. Lithium-ion cell heat exchangers must activate pre-heating protocols when ambient temperatures plummet below -10°C (14°F) to prevent localized lithium plating.'
      },
      {
        source: 'Hydraulic-Decel-Brakes.pdf',
        category: 'Braking Systems',
        text: 'Safety concerns have arisen regarding the secondary deceleration system (hydraulic brake calipers). Under extreme ice or slush conditions (-15°C or lower), road melt chemicals can crust inside the micro-actuator seals of the secondary calipers. This causes a delayed emergency brake pressure response (up to 450ms lag). Technical fix: apply silicon dust-jackets to caliper actuators under Bulletin SEC-BRAKE-09.'
      },
      {
        source: 'Traction-Control-FAQ.pdf',
        category: 'Traction FAQ',
        text: 'Traction control software utilizes differential regenerative torque allocation to resolve sliding. Cold weather traction is handled natively by the dual-motor inverter and does not rely on physical brakes.'
      }
    ],
    get chunks() {
      return this.documents.map((doc, idx) => ({
        id: `chunk-${this.id}-${idx}`,
        source: doc.source,
        content: doc.text
      }));
    }
  }
];

export interface CustomPresetRun {
  datasetId: string;
  name: string;
  query: string;
  standardRun: {
    retrievedChunks: string[]; // document sources
    answer: string;
    steps: { nodeId: string; status: 'completed' | 'failed' | 'warning'; detail: string }[];
  };
  agenticRun: {
    retrievedChunks: string[]; // document sources
    answer: string;
    steps: { nodeId: string; status: 'completed' | 'warning' | 'active'; detail: string }[];
  };
}

export const PRESET_RUNS: CustomPresetRun[] = [
  {
    datasetId: 'health-benefits',
    name: 'Mental Health diagnostics eligibility',
    query: 'Can I get reimbursed for a specialized cognitive mental health assessment in August under our corporate policy?',
    standardRun: {
      retrievedChunks: ['HR-Policy-Sec-4.pdf'],
      answer: 'Yes. According to corporate policy, standard mental health therapy sessions are reimbursed at 80% of costs, up to a maximum limit of $1,000 per fiscal year. You must submit your claims within 60 days of the assessment.',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "Can I get reimbursed for a specialized cognitive mental health assessment in August under our corporate policy?"' },
        { nodeId: 'embed', status: 'completed', detail: 'Generated query embedding vector using 1536 dimensions.' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Executed cosine similarity search. Top matching document retrieved is "HR-Policy-Sec-4.pdf" (relevance score: 0.81) due to semantic match with "mental health assessment". Passed this chunk to synthesis.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'Assembled LLM context from general reimbursement limits.' },
        { nodeId: 'response', status: 'completed', detail: 'Completed output: standard therapy terms.' }
      ]
    },
    agenticRun: {
      retrievedChunks: ['HR-Policy-Sec-4.pdf', 'HR-Policy-Rider-12B.pdf'],
      answer: 'No, you cannot get the specialized cognitive assessment fully reimbursed in August under Rider 12B. \n\nUnder corporate insurance rules, specialized cognitive/neuro-divergent assessments (Rider 12B) qualify for 100% reimbursement (up to $3,000) **only if** you file a pre-approval request by **June 30th**. Since you are seeking this assessment in August (past the deadline), your assessment is strictly excluded from Rider 12B and will instead be processed under standard mental health therapy limits (which offer only 80% coverage up to a $1,000 fiscal year maximum).',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "Can I get reimbursed for a specialized cognitive mental health assessment in August under our corporate policy?"' },
        { nodeId: 'router', status: 'completed', detail: 'Router Agent designated query intent as "Corporate Policy - Benefits Exception". Routed to both the Benefits policy index and specialized neuro-divergent rider indices.' },
        { nodeId: 'query-refinement', status: 'completed', detail: 'Optimized search queries to: "specialized cognitive mental health assessment policy" AND "neuro-divergent diagnostic reimbursement dates".' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Executed parallel Vector DB retrieval. Retrieved standard limit document "HR-Policy-Sec-4.pdf" (Relevance: 0.79) and rider exclusion document "HR-Policy-Rider-12B.pdf" (Relevance: 0.85).' },
        { nodeId: 'doc-evaluator', status: 'completed', detail: 'Evaluation Agent graded "HR-Policy-Rider-12B" as CRITICAL. Identified that August assessments fail the June 30th pre-approval rider terms, transferring a hard restriction to the model.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'Synthesized dual facts (rider dates vs standard caps) into a unified corporate response.' },
        { nodeId: 'hallucination-grader', status: 'completed', detail: 'Grounding Agent verified answer against policy rules: confirmed 100% success rate, verified the August timeline exclusion is 100% faithful to the text.' },
        { nodeId: 'response', status: 'completed', detail: 'Generated completed, bulletproof policy response.' }
      ]
    }
  },
  {
    datasetId: 'quantum-vc',
    name: 'Hardware coherence performance limits',
    query: 'What is our T2 coherence time, and how much better is our new design?',
    standardRun: {
      retrievedChunks: ['Patent-AQ-9082.pdf'],
      answer: 'Our average T2 coherence time is 120 microseconds using proprietary superconducting transmon qubits. There is no mention of a newer design in the retrieved documents.',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "What is our T2 coherence time, and how much better is our new design?"' },
        { nodeId: 'embed', status: 'completed', detail: 'Created vector embeddings.' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Cosine search. Top chunk returned: "Patent-AQ-9082.pdf" (Relevance: 0.84) containing transmon 120µs statistics. Investor milestone document and experimental designs had lower match score on general "T2 coherence time" keywords, so they were truncated.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'Formed response with standard patent coherence parameters.' },
        { nodeId: 'response', status: 'completed', detail: 'Output generated.' }
      ]
    },
    agenticRun: {
      retrievedChunks: ['Patent-AQ-9082.pdf', 'Lab-Report-Fluxonium.pdf'],
      answer: 'Our standard superconducting transmon qubits have a T2 coherence time of **120 microseconds**. \n\nOur experimental "Flux-9" fluxonium-style circuit design achieves a coherence time exceeding **1,400 microseconds** (1.4 milliseconds). This represents a **11.6x improvement** (>10x) over Standard transmons, drastically increasing resilience to charge noise, though it introduces a tighter operating parameter restricting microwave bias strictly between 0.49 and 0.51 flux quanta.',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "What is our T2 coherence time, and how much better is our new design?"' },
        { nodeId: 'router', status: 'completed', detail: 'Router Agent activated. Classified query as a "quantitative comparison query" requiring both baseline specification and experimental targets.' },
        { nodeId: 'query-refinement', status: 'completed', detail: 'Split query into search vectors: 1) "baseline superconducting qubit T2 coherence" and 2) "experimental qubit design coherence improvement Fluxonium".' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Retrieved "Patent-AQ-9082.pdf" (transmon baselines) and "Lab-Report-Fluxonium.pdf" (experimental Fluxonium metrics).' },
        { nodeId: 'doc-evaluator', status: 'completed', detail: 'Evaluator Agent analyzed context: Graded both chunks as highly relevant (1.0). Confirmed the mathematical calculation: 1400/120 = 11.66x.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'Instructed LLM to construct a comparative performance matrix.' },
        { nodeId: 'hallucination-grader', status: 'completed', detail: 'Scored answer: All terms verified against patent flux records. Mathematical division verified.' },
        { nodeId: 'response', status: 'completed', detail: 'Delivered comparative quantum performance profile.' }
      ]
    }
  },
  {
    datasetId: 'ev-safety',
    name: 'Braking system safety alerts',
    query: 'Do we have any safety notices regarding brake calipers failing in winter conditions?',
    standardRun: {
      retrievedChunks: ['Recall-Notification-2025-A.pdf', 'Traction-Control-FAQ.pdf'],
      answer: 'According to our service logs, there are cold weather procedures regarding Lithium-ion cell heat exchangers which must activate pre-heating protocols when temperatures drop below -10°C (14°F) to prevent lithium plating. Traction control is also handled natively in cold weather using differential regenerative torque. There are no notices regarding brake calipers failing.',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "Do we have any safety notices regarding brake calipers failing in winter conditions?"' },
        { nodeId: 'embed', status: 'completed', detail: 'Calculated embedding representation.' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Query matched "Recall-Notification-2025-A.pdf" (Relevance: 0.72) and "Traction-Control-FAQ.pdf" (Relevance: 0.69) due to "winter conditions" and "battery/traction control" matching. The specific braking manual was under a different engineering terminology ("deceleration hydraulics systems") and missed target keywords, so it failed to retrieve.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'LLM summarized that only battery preheating and traction logs address cold weather safety.' },
        { nodeId: 'response', status: 'completed', detail: 'Completed query with incomplete brake safety analysis.' }
      ]
    },
    agenticRun: {
      retrievedChunks: ['Hydraulic-Decel-Brakes.pdf'],
      answer: 'Yes, we have an active safety concern regarding hydraulic brake calipers in extreme cold and slush conditions (-15°C or lower).\n\nChemicals used to melt ice on winter roads can crust inside the micro-actuator seals of the secondary system. This crusting delays active calipers braking press, introducing a significant **emergency braking delay lag of up to 450ms**. \n\n**Required Safety Action:** Clean seals and apply silicon dust-jackets under official **Bulletin SEC-BRAKE-09** override protocols.',
      steps: [
        { nodeId: 'query', status: 'completed', detail: 'Received query: "Do we have any safety notices regarding brake calipers failing in winter conditions?"' },
        { nodeId: 'router', status: 'completed', detail: 'Router classified intent as "Safety recall hazard inspection". Armed high priority extraction protocols.' },
        { nodeId: 'query-refinement', status: 'completed', detail: 'Generated search vector: "brake caliper failure cold winter deceleration hazard bulletin recall".' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Retrieved "Recall-Notification-2025-A.pdf" (0.7) and "Traction-Control-FAQ" (0.65). However, Relevance Grader marked these chunks as LOW RELEVANCE (0.4) because they did not address "brake calipers" and "fail".' },
        { nodeId: 'doc-evaluator', status: 'warning', detail: 'Safety Grader detected query-context disparity! Initiated a correction query rewrite focusing on engineering hydraulic components.' },
        { nodeId: 'query-refinement', status: 'completed', detail: 'Optimized query iteration: "hydraulic deceleration systems brake pressure delay cold temperatures".' },
        { nodeId: 'vector-db', status: 'completed', detail: 'Re-queried database. Retrieved "Hydraulic-Decel-Brakes.pdf" with outstanding 0.95 relevance match.' },
        { nodeId: 'doc-evaluator', status: 'completed', detail: 'Evaluator verified hydraulic crusting chunk as CRITICAL and relevant.' },
        { nodeId: 'synthesize', status: 'completed', detail: 'Generated specific mechanical recall instructions.' },
        { nodeId: 'hallucination-grader', status: 'completed', detail: 'Self-grader verified delay figures (450ms) and code (Bulletin SEC-BRAKE-09). Passed.' },
        { nodeId: 'response', status: 'completed', detail: 'Completed bulletproof EV winter safety advisory.' }
      ]
    }
  }
];

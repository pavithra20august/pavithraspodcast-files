import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { DATASETS } from "./src/data/datasets.js";

// Ensure process env is loaded
dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
      return null;
    }
    try {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    } catch (e) {
      console.warn("Failed to initialize GoogleGenAI:", e);
      return null;
    }
  }
  return aiClient;
}

// Simple local fallback simulator when Gemini key is missing
function localRAGSimulation(datasetId: string, query: string, type: 'standard' | 'agentic') {
  // Find dataset
  const dataset = DATASETS.find(d => d.id === datasetId) || DATASETS[0];
  const lowerQuery = query.toLowerCase();

  // Helper keyword matching
  const scoredChunks = dataset.chunks.map(chunk => {
    const words = lowerQuery.split(/\s+/);
    let matchCount = 0;
    words.forEach(word => {
      if (word.length > 2 && chunk.content.toLowerCase().includes(word)) {
        matchCount++;
      }
    });

    // Custom boosts for certain datasets to highlight the agentic RAG benefit offline
    if (datasetId === 'health-benefits') {
      if (lowerQuery.includes('august') || lowerQuery.includes('september')) {
        if (chunk.source.includes('Rider-12B')) matchCount += 1.5; // push rider representation
      }
    } else if (datasetId === 'quantum-vc') {
      if (lowerQuery.includes('better') || lowerQuery.includes('new design') || lowerQuery.includes('flux')) {
        if (chunk.source.includes('Fluxonium')) matchCount += 2;
      }
    } else if (datasetId === 'ev-safety') {
      if (lowerQuery.includes('brake') || lowerQuery.includes('calipers')) {
        if (chunk.source.includes('Brakes')) matchCount += 3;
      }
    }

    const score = matchCount / (words.length || 1);
    return { chunk, score };
  }).sort((a, b) => b.score - a.score);

  if (type === 'standard') {
    // Standard RAG takes top chunk only or has poor context separation
    const bestMatch = scoredChunks[0];
    const retrieved = bestMatch && bestMatch.score > 0 ? [bestMatch.chunk] : [dataset.chunks[0]];

    let answer = "";
    if (datasetId === 'health-benefits') {
      answer = "Standard RAG Answer:\nYes, mental health therapy is generally covered at 80% up to $1,000 per fiscal year. You should submit your claim within 60 days of your appointment in August. Please check HR limits online.";
    } else if (datasetId === 'quantum-vc') {
      answer = "Standard RAG Answer:\nOur standard superconducting transmon qubits operate at quantum coherence times (T2) averaging 120 microseconds with an energy ratio Ej/Ec of 50 in our active shielding chambers.";
    } else {
      answer = "Standard RAG Answer:\nOmniDrive vehicles have a winter bulletin indicating that cell heat exchangers must heat battery cells if the environment drops under -10°C (14°F) to protect performance. Traction answers are standard.";
    }

    return {
      pipelineType: 'standard',
      query,
      steps: [
        {
          id: 'step1',
          nodeId: 'query',
          title: 'Query Input',
          description: 'Acquired user query and initialized standard context extraction.',
          status: 'completed',
          durationMs: 40,
          outputDetails: `Query: "${query}"`
        },
        {
          id: 'step2',
          nodeId: 'embed',
          title: 'Query Embedding',
          description: 'Converted input query text directly into mathematical dense vector representation.',
          status: 'completed',
          durationMs: 90,
          outputDetails: 'Embedding vector dimensions: [1536 float32]'
        },
        {
          id: 'step3',
          nodeId: 'vector-db',
          title: 'Index Search',
          description: 'Searched standard vector indices via cosine similarity on Top-1 K neighbors.',
          status: 'completed',
          durationMs: 150,
          outputDetails: `Fetched matched chunk: "${retrieved[0].source}" with matching score: ${Math.max(0.5, bestMatch?.score || 0).toFixed(2)}. Minor indices truncated to prevent cost spikes.`
        },
        {
          id: 'step4',
          nodeId: 'synthesize',
          title: 'Synthesis',
          description: 'Constructed LLM instruction context and generated answer using the top returned context chunk.',
          status: 'completed',
          durationMs: 350,
          outputDetails: `Prompt template: "Given context, answer question..."`
        },
        {
          id: 'step5',
          nodeId: 'response',
          title: 'Standard Answer Delivered',
          description: 'Formatted and pushed response text to client console.',
          status: 'completed',
          durationMs: 20,
          outputDetails: 'Answer payload generated successfully.'
        }
      ],
      retrievedChunks: retrieved,
      finalAnswer: answer,
      citations: retrieved.map(c => c.source),
      executionTimeMs: 650,
      costEstimateCents: 0.012
    };
  } else {
    // Agentic RAG Simulation (Correction loop offline)
    // Multi-chunk matching
    const retrieved = scoredChunks.filter(sc => sc.score > 0.05).map(sc => sc.chunk);
    if (retrieved.length === 0) {
      retrieved.push(dataset.chunks[0], dataset.chunks[1]);
    }

    let answer = "";
    if (datasetId === 'health-benefits') {
      answer = "**Agentic RAG Response (Corrective Policy Verification):**\n\nNo, specialized cognitive or neuro-divergent assessments under **Rider 12B** are **NOT** eligible for reimbursement in August. \n\n**Reasoning:**\n- Specialized diagnostic assessment categories have a strict cutoff for authorization. Your pre-approval requested must be submitted by **June 30th**.\n- Since August is past this threshold, you will instead fall back to standard mental health billing covered in **HR-Policy-Sec-4.pdf**, which limits claims to **80% of costs, up to $1,000 maximum**.\n\n*Action suggested:* Please coordinate with HR to investigate standard claim submission limits.";
    } else if (datasetId === 'quantum-vc') {
      answer = "**Agentic RAG Response (Exploratory Quantum Profile):**\n\nWe have analyzed our active configurations from both baseline patents and laboratories:\n\n1. **Standard Transmon Architecture (Baseline):** Exhibits average coherence times (T2) of **120 microseconds** operating under general cryogenic systems.\n2. **New Flux-9 Design (Heavy Fluxonium):** Delivers a T2 coherence time exceeding **1,400 microseconds** (1.4 milliseconds).\n\n**Performance Increase:** This represents a massive **11.6x improvement** in noise immunity, enabling an upgrade in logical qubit fidelity from 99.9% to 99.99%. However, it mandates that you regulate electromagnetic environments strictly within **0.49 - 0.51 flux quanta**.";
    } else {
      answer = "**Agentic RAG Response (Safety Hazard Analysis):**\n\nYes, an engineering alert exists regarding brake caliper actuation in severe winter elements (-15°C or lower).\n\n**Identified Failure:**\n- Road chemicals used to clear slush can seep into and crystallize inside the micro-actuator caliper seals.\n- This introduces up to a **450ms lag in brake pressure delivery** during emergency commands.\n\n**Mandated Action:**\n- In winter conditions, apply custom silicon dust-jackets immediately, in compliance with safety policy directive **SEC-BRAKE-09**.";
    }

    return {
      pipelineType: 'agentic',
      query,
      steps: [
        {
          id: 'step1',
          nodeId: 'query',
          title: 'Query Received',
          description: 'Captured user question. Dispatched to Router agent.',
          status: 'completed',
          durationMs: 40
        },
        {
          id: 'step2',
          nodeId: 'router',
          title: 'Routing Decision',
          description: 'Router Agent analyzed intent. Determined that specialized riders and safety guidelines must be cross-referenced.',
          status: 'completed',
          durationMs: 120,
          outputDetails: 'Route: [Policy Exceptions Index, Specialized Subsections]'
        },
        {
          id: 'step3',
          nodeId: 'query-refinement',
          title: 'Query Refinement',
          description: 'Optimized search strings to expand sparse terminology overlap into distinct structured keys.',
          status: 'completed',
          durationMs: 90,
          outputDetails: `Query transformed to focus on constraints, safety numbers, and calendar boundaries.`
        },
        {
          id: 'step4',
          nodeId: 'vector-db',
          title: 'Knowledge Extraction',
          description: 'Queried Vector DB with multithreaded semantic keys.',
          status: 'completed',
          durationMs: 160,
          outputDetails: `Extracted matched chunks: ${retrieved.map(r => r.source).join(", ")}.`
        },
        {
          id: 'step5',
          nodeId: 'doc-evaluator',
          title: 'Relevance Grading',
          description: 'Evaluation Agent scrutinized retrieved articles. Checked if context fully satisfies multi-hop query parameters.',
          status: 'completed',
          durationMs: 140,
          outputDetails: 'Graded matches: Found specific critical thresholds (e.g. June 30 limit / brake bulletin). Status: APPROVED.'
        },
        {
          id: 'step6',
          nodeId: 'synthesize',
          title: 'Synthesis & Generation',
          description: 'Aggregated verified facts and compiled response mapping constraints, warning points, and statistics.',
          status: 'completed',
          durationMs: 450,
          outputDetails: 'LLM generated integrated policy draft.'
        },
        {
          id: 'step7',
          nodeId: 'hallucination-grader',
          title: 'Self-Correction Audit',
          description: 'Grounding Agent double-checked every numerical claim in output against primary document bytes.',
          status: 'completed',
          durationMs: 110,
          outputDetails: 'Validation Score: 100/100. Veracity checks against recall bulletin numbers matched perfectly.'
        },
        {
          id: 'step8',
          nodeId: 'response',
          title: 'Agentic Answer Formulated',
          description: 'Returned audited answer to frontend viewport client.',
          status: 'completed',
          durationMs: 30
        }
      ],
      retrievedChunks: retrieved,
      finalAnswer: answer,
      citations: retrieved.map(c => c.source),
      executionTimeMs: 1140,
      costEstimateCents: 0.115
    };
  }
}

// API endpoint to process query
app.post("/api/rag", async (req, res) => {
  const { datasetId, query, pipelineType } = req.body;

  if (!datasetId || !query) {
    return res.status(400).json({ error: "Missing datasetId or query value." });
  }

  const ai = getGeminiClient();

  // If no Gemini API Client sits in environment, return high-fidelity local simulation
  if (!ai) {
    console.log("No Gemini API key detected. Running high fidelity local RAG simulation.");
    const simResult = localRAGSimulation(datasetId, query, pipelineType);
    return res.json(simResult);
  }

  // Find dataset
  const dataset = DATASETS.find(d => d.id === datasetId) || DATASETS[0];

  try {
    const isStandard = pipelineType === 'standard';
    
    // Construct the prompt context
    const documentsContext = dataset.documents.map((doc, idx) => {
      return `[DOCUMENT ${idx + 1}] Source: ${doc.source}\nCategory: ${doc.category}\nContent: ${doc.text}\n`;
    }).join("\n");

    const prompt = `
      You are an expert simulator of Retrieve-Augmented Generation (RAG) pipelines. Your job is to process the user's query against the provided documents and simulate the response steps for both "standard" and "agentic" approaches.
      
      User Query: "${query}"
      
      Available Corpus Documents:
      ${documentsContext}

      Requested Pipeline Simulation: ${pipelineType.toUpperCase()} RAG

      Please generate a JSON object conforming STRICTLY to this TypeScript interface:
      interface SimulationResult {
        pipelineType: 'standard' | 'agentic';
        query: string;
        steps: Array<{
          id: string; // e.g. 'step1', 'step2'
          nodeId: string; // Must match one of these valid nodes: 'query', 'router', 'query-refinement', 'vector-db', 'doc-evaluator', 'synthesize', 'hallucination-grader', 'response'
          title: string; // The step name (e.g. Router Decision, Grounding check, Answer Formulation)
          description: string; // What the agent or element did in this step
          status: 'completed' | 'warning' | 'active' | 'failed';
          outputDetails?: string; // Rich logs/parameters checked (highly detailed values / reasoning)
          durationMs: number; // simulated execution duration
        }>;
        retrievedChunks: Array<{
          id: string;
          source: string;
          content: string;
          relevanceScore: number; // a number between 0 and 1 representing relevance
        }>;
        finalAnswer: string; // The markdown response. If Standard RAG, make it somewhat naive, literally answering based on shallow matches (might miss date exclusions or secondary documents). If Agentic RAG, make it a masterclass answer that handles temporal conditions, resolves conflicts, summarizes and acts like a corrected verified answer.
        citations: string[]; // Sources integrated (e.g., ["HR-Policy-Sec-4.pdf"])
        executionTimeMs: number; // total cumulative simulated time
        costEstimateCents: number; // simulated token fee estimation
      }

      CRITICAL DIRECTIONS FOR PIPELINES:
      1. STANDARD MODE: 
         - Simulates standard naive Vector DB pull.
         - Standard pipelines perform a single cosine search based on simple keyword overlap.
         - They match the direct keywords. If a different document had critical exclusions but had lower keyword overlap (or required multi-step search), the standard pipeline missed it because it only got the single top document.
         - The answer must be standard, failing to catch deeper exclusions or riders (e.g., missing Agentic correction elements).
         - Use ONLY these nodeIds: 'query', 'embed', 'vector-db', 'synthesize', 'response'. (Note: 'embed' is a valid node representing embedding generation).

      2. AGENTIC MODE: 
         - Simulates advanced self-corrective RAG (Self-RAG or Corrective RAG).
         - Steps MUST describe the interaction of Router Agents, Query Optimization, initial retrieval, Relevance Grading (Doc evaluation), potential query rewriting (if some query parameters like dates are outstanding), deep context synthesis, hallucination grading (double-checking numerical or factual grounding), and safety response gatekeeping.
         - This should be visually spectacular, rich in details, showing why Agentic RAG resolved details that the Standard RAG missed!
         - Use any of these nodeIds as appropriate: 'query', 'router', 'query-refinement', 'vector-db', 'doc-evaluator', 'synthesize', 'hallucination-grader', 'response'.

      Respond directly with the valid compile-ready JSON inside a markdown code block. Do not write any other explanation or pleasantries.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const cleanResultText = response.text || "";
    const parsedData = JSON.parse(cleanResultText.trim());

    return res.json(parsedData);
  } catch (error: any) {
    console.error("Gemini RAG API Error:", error);
    // In case of any error from API, fall back gracefully to offline generator
    const fallback = localRAGSimulation(datasetId, query, pipelineType);
    return res.json(fallback);
  }
});

// Serve UI assets with async bootstrap to avoid top-level await in CJS formats
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RAG Visualizer Server booted on port ${PORT}`);
  });
}

bootstrap();
